import type { RedisClient } from "bun";
import type {
  PageCacheAdapter,
  PageCacheEntry,
  PageCacheIdentity,
  PageCacheLease,
} from "../page-cache.ts";
import {
  ACQUIRE_PAGE_CACHE_LEASE_SCRIPT,
  COMMIT_PAGE_CACHE_ENTRY_SCRIPT,
  INVALIDATE_PAGE_CACHE_PATH_SCRIPT,
  INVALIDATE_PAGE_CACHE_TAGS_SCRIPT,
  READ_PAGE_CACHE_ENTRY_SCRIPT,
  RELEASE_PAGE_CACHE_LEASE_SCRIPT,
} from "./scripts.ts";

const TRAILING_SLASHES = /\/+$/;
const DEFAULT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
const METADATA_GRACE_MS = 24 * 60 * 60 * 1000;

export interface RedisPageCacheOptions {
  client: RedisClient;
  namespace: string;
  retentionMs?: number;
}

interface RedisLeaseDocument {
  expiresAt: number;
  fence: number;
  fields: string[];
  id: string;
  values: number[];
}

interface RedisEntryDocument {
  entry: PageCacheEntry;
  fields: string[];
  indexMember: string;
  pathsKey: string;
  tagKeys: string[];
  values: number[];
}

interface RedisIndexMember {
  entryKey: string;
  path: string;
  pathsKey: string;
  tagKeys: string[];
}

function assertNamespace(namespace: string): void {
  if (namespace.length === 0) {
    throw new Error("[furin-page-cache-redis] namespace must not be empty.");
  }
  if (!namespace.isWellFormed()) {
    throw new Error("[furin-page-cache-redis] namespace must contain valid Unicode.");
  }
}

function digest(value: string): string {
  return new Bun.CryptoHasher("sha256").update(value).digest("hex");
}

function identityDigest(identity: PageCacheIdentity): string {
  return digest(JSON.stringify([identity.scope, identity.buildId, identity.mode, identity.key]));
}

function layoutPaths(path: string): string[] {
  if (path === "/") {
    return ["/"];
  }
  const paths = ["/"];
  let current = "";
  for (const segment of path.split("/").filter(Boolean)) {
    current += `/${segment}`;
    paths.push(current);
  }
  return paths;
}

function normalizeInvalidationPath(path: string): string {
  return path.length > 1 ? path.replace(TRAILING_SLASHES, "") : path;
}

function selectorFields(identity: PageCacheIdentity): string[] {
  return [
    `page:${identity.path}`,
    ...layoutPaths(identity.path).map((path) => `layout:${path}`),
    ...identity.tags.map((tag) => `tag:${tag}`),
  ];
}

function stringResult(value: unknown, operation: string): string {
  if (typeof value !== "string") {
    throw new Error(`[furin-page-cache-redis] Invalid ${operation} response.`);
  }
  return value;
}

function stringArrayResult(value: unknown, operation: string): string[] {
  if (!Array.isArray(value) || value.some((entry) => typeof entry !== "string")) {
    throw new Error(`[furin-page-cache-redis] Invalid ${operation} response.`);
  }
  return value as string[];
}

function parseLease(raw: string): RedisLeaseDocument {
  const value: unknown = JSON.parse(raw);
  if (
    typeof value !== "object" ||
    value === null ||
    !("expiresAt" in value) ||
    typeof value.expiresAt !== "number" ||
    !("fence" in value) ||
    typeof value.fence !== "number" ||
    !("fields" in value) ||
    !Array.isArray(value.fields) ||
    value.fields.some((field) => typeof field !== "string") ||
    !("id" in value) ||
    typeof value.id !== "string" ||
    !("values" in value) ||
    !Array.isArray(value.values) ||
    value.values.some((revision) => typeof revision !== "number")
  ) {
    throw new Error("[furin-page-cache-redis] Invalid lease document.");
  }
  return value as RedisLeaseDocument;
}

function parseEntry(raw: string): PageCacheEntry {
  const value: unknown = JSON.parse(raw);
  if (
    typeof value !== "object" ||
    value === null ||
    !("entry" in value) ||
    typeof value.entry !== "object" ||
    value.entry === null ||
    !("cachedAt" in value.entry) ||
    typeof value.entry.cachedAt !== "number" ||
    !("payload" in value.entry) ||
    typeof value.entry.payload !== "string" ||
    !("revalidate" in value.entry) ||
    (typeof value.entry.revalidate !== "number" && value.entry.revalidate !== null)
  ) {
    throw new Error("[furin-page-cache-redis] Invalid cache entry document.");
  }
  return value.entry as PageCacheEntry;
}

export class RedisPageCache implements PageCacheAdapter {
  private readonly client: RedisClient;
  private readonly metadataRetentionMs: number;
  private readonly prefix: string;
  private readonly retentionMs: number;

  constructor(options: RedisPageCacheOptions) {
    assertNamespace(options.namespace);
    const retentionMs = options.retentionMs ?? DEFAULT_RETENTION_MS;
    if (
      !Number.isSafeInteger(retentionMs) ||
      retentionMs <= 0 ||
      retentionMs > Number.MAX_SAFE_INTEGER - METADATA_GRACE_MS
    ) {
      throw new Error("[furin-page-cache-redis] retentionMs must be a positive safe integer.");
    }
    this.client = options.client;
    this.prefix = `furin:page:{${encodeURIComponent(options.namespace)}}`;
    this.retentionMs = retentionMs;
    this.metadataRetentionMs = retentionMs + METADATA_GRACE_MS;
  }

  async acquire({
    identity,
    leaseMs,
  }: {
    identity: PageCacheIdentity;
    leaseMs: number;
  }): Promise<PageCacheLease | null> {
    const id = crypto.randomUUID();
    const keys = [
      this.leaseKey(identity),
      this.fenceKey(identity),
      this.versionsKey(identity.scope),
      this.leasesKey(identity.scope),
      ...[...new Set(identity.tags)].map((tag) => this.tagLeasesKey(identity.scope, tag)),
    ];
    const raw = await this.client.send("EVAL", [
      ACQUIRE_PAGE_CACHE_LEASE_SCRIPT,
      String(keys.length),
      ...keys,
      id,
      String(leaseMs),
      JSON.stringify(selectorFields(identity)),
      String(this.metadataRetentionMs),
      identity.path,
      JSON.stringify(identity.tags),
    ]);
    if (raw === null) {
      return null;
    }
    const lease = parseLease(stringResult(raw, "lease acquisition"));
    return {
      expiresAt: lease.expiresAt,
      fence: lease.fence,
      id: lease.id,
      revision: JSON.stringify(lease.values),
    };
  }

  async commit({
    entry,
    identity,
    lease,
  }: {
    entry: PageCacheEntry;
    identity: PageCacheIdentity;
    lease: PageCacheLease;
  }): Promise<"stored" | "superseded"> {
    const tagKeys = [...new Set(identity.tags)].map((tag) => this.tagPathsKey(identity.scope, tag));
    const entryKey = this.entryKey(identity);
    const pathsKey = this.pathsKey(identity.scope);
    const indexMember = JSON.stringify({
      entryKey,
      path: identity.path,
      pathsKey,
      tagKeys,
    } satisfies RedisIndexMember);
    const document: RedisEntryDocument = {
      entry,
      fields: selectorFields(identity),
      indexMember,
      pathsKey,
      tagKeys,
      values: JSON.parse(lease.revision) as number[],
    };
    const keys = [
      this.leaseKey(identity),
      entryKey,
      this.versionsKey(identity.scope),
      pathsKey,
      this.leasesKey(identity.scope),
      ...tagKeys,
    ];
    const result = await this.client.send("EVAL", [
      COMMIT_PAGE_CACHE_ENTRY_SCRIPT,
      String(keys.length),
      ...keys,
      lease.id,
      String(lease.fence),
      JSON.stringify(document),
      indexMember,
      String(this.retentionMs),
      String(this.metadataRetentionMs),
    ]);
    if (result === "stored" || result === "superseded") {
      return result;
    }
    throw new Error("[furin-page-cache-redis] Invalid cache commit response.");
  }

  async invalidate(input: Parameters<PageCacheAdapter["invalidate"]>[0]) {
    if (input.kind === "path") {
      const path = normalizeInvalidationPath(input.path);
      const result = stringArrayResult(
        await this.client.send("EVAL", [
          INVALIDATE_PAGE_CACHE_PATH_SCRIPT,
          "3",
          this.versionsKey(input.scope),
          this.pathsKey(input.scope),
          this.leasesKey(input.scope),
          `${input.type}:${path}`,
          path,
          input.type,
          String(this.metadataRetentionMs),
        ]),
        "path invalidation"
      );
      return { invalidated: result.length > 0, paths: result };
    }

    const tags = [...new Set(input.tags)];
    const keys = [
      this.versionsKey(input.scope),
      this.pathsKey(input.scope),
      this.leasesKey(input.scope),
      ...tags.map((tag) => this.tagPathsKey(input.scope, tag)),
      ...tags.map((tag) => this.tagLeasesKey(input.scope, tag)),
    ];
    const result = stringArrayResult(
      await this.client.send("EVAL", [
        INVALIDATE_PAGE_CACHE_TAGS_SCRIPT,
        String(keys.length),
        ...keys,
        JSON.stringify(tags),
        String(this.metadataRetentionMs),
      ]),
      "tag invalidation"
    );
    return { invalidated: result.length > 0, paths: result };
  }

  async read(identity: PageCacheIdentity): Promise<PageCacheEntry | null> {
    const raw = await this.client.send("EVAL", [
      READ_PAGE_CACHE_ENTRY_SCRIPT,
      "2",
      this.entryKey(identity),
      this.versionsKey(identity.scope),
    ]);
    if (raw === null) {
      return null;
    }
    return parseEntry(stringResult(raw, "cache read"));
  }

  async release({
    identity,
    lease,
  }: {
    identity: PageCacheIdentity;
    lease: PageCacheLease;
  }): Promise<void> {
    await this.client.send("EVAL", [
      RELEASE_PAGE_CACHE_LEASE_SCRIPT,
      "2",
      this.leaseKey(identity),
      this.leasesKey(identity.scope),
      lease.id,
      String(lease.fence),
    ]);
  }

  private entryKey(identity: PageCacheIdentity): string {
    return `${this.prefix}:entry:${identityDigest(identity)}`;
  }

  private fenceKey(identity: PageCacheIdentity): string {
    return `${this.prefix}:fence:${identityDigest(identity)}`;
  }

  private leaseKey(identity: PageCacheIdentity): string {
    return `${this.prefix}:lease:${identityDigest(identity)}`;
  }

  private pathsKey(scope: string): string {
    return `${this.prefix}:paths:${digest(scope)}`;
  }

  private leasesKey(scope: string): string {
    return `${this.prefix}:leases:${digest(scope)}`;
  }

  private tagPathsKey(scope: string, tag: string): string {
    return `${this.prefix}:tag-paths:${digest(scope)}:${digest(tag)}`;
  }

  private tagLeasesKey(scope: string, tag: string): string {
    return `${this.prefix}:tag-leases:${digest(scope)}:${digest(tag)}`;
  }

  private versionsKey(scope: string): string {
    return `${this.prefix}:versions:${digest(scope)}`;
  }
}

export function redisPageCache(options: RedisPageCacheOptions): PageCacheAdapter {
  return new RedisPageCache(options);
}

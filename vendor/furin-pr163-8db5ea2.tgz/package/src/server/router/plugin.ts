import { type AnyElysia, type Context, Elysia, problem } from "elysia";
import { toCrossJSONAsync } from "seroval";
import type { HeadOptions } from "../../client.ts";
import { computeErrorDigest } from "../../shared/digest.ts";
import type { FurinSchema } from "../../shared/elysia-contract.ts";
import { physicalPath } from "../../shared/prefix.ts";
import { containsRscSource } from "../../shared/route-frame.ts";
import type { SearchParamsInput, SearchRouteMetadata } from "../../shared/search-params.ts";
import { getLogger } from "../context-logger.ts";
import {
  currentInstrumentationRequest,
  emitPayloadSerialized,
} from "../devtools/instrumentation.ts";
import { isExternalPrerenderRequest } from "../external-prerender.ts";
import { currentInstance } from "../instance.ts";
import { injectSyncRuntimeScript, resolvePath } from "../render/assemble.ts";
import { handleISR } from "../render/isr.ts";
import {
  hasMixedLoaderModes,
  hasRequestLoader,
  type LoaderResult,
  runLoaders,
  runMixedLoaders,
  runPublicLoaders,
  withRequestLoaderData,
} from "../render/loaders.ts";
import { renderPprRoute, runPprPublicLoaders } from "../render/ppr-route.ts";
import { createDeferredRouteFrameStream } from "../render/route-frame-transport.ts";
import { extractTitle } from "../render/shell.ts";
import { prerenderRoute, prerenderRuntimeSSG } from "../render/ssg.ts";
import { renderSSR, serializeLoaderDataNdjson } from "../render/ssr.ts";
import { IS_DEV } from "../runtime-env.ts";
import { handleDevRequest, reportDevRouteFailure } from "./hmr.ts";
import { buildRouteMatcher, resolveDocumentMode, resolveDocumentRevalidate } from "./patterns.ts";
import { mergeRouteSchemas } from "./schema-merge.ts";
import {
  createSearchRouteMetadata,
  parseDataEndpointPath,
  parseRouteParams,
  parseRouteQuery,
} from "./schemas.ts";
import type { ResolvedRoute, ResolvedRoutesSource, RootLayout } from "./types.ts";

const MAX_NAVIGATION_HEAD_BYTES = 64 * 1024;

type DataResolvedRoutesSource =
  | ResolvedRoutesSource
  | ((request: Request) => Promise<ResolvedRoute[]>);
type RefreshDevRoute = (
  route: ResolvedRoute
) => Promise<{ route: ResolvedRoute; root: RootLayout }>;
type DataRouteResolver = (
  route: ResolvedRoute
) => Promise<{ route: ResolvedRoute; root: RootLayout | undefined }>;

interface DataRouteParamsInput {
  [key: string]: unknown;
}

type SyntheticDataContext = Omit<Context, "params" | "query"> & {
  params: DataRouteParamsInput;
  query: SearchParamsInput;
};

type RouteDataContext = Pick<SyntheticDataContext, "params" | "path" | "query">;

function emitSerializedPayload(body: string, kind: "route-data" | "rsc", requestUrl: string): void {
  if (!IS_DEV) {
    return;
  }
  const request = currentInstrumentationRequest();
  if (request === undefined) {
    return;
  }
  emitPayloadSerialized({
    bytes: new TextEncoder().encode(body).byteLength,
    kind,
    operationId: request.operationId,
    path: new URL(requestUrl).pathname,
    requestId: request.requestId,
  });
}

async function runDataEndpointLoaders(
  route: ResolvedRoute,
  ctx: Context,
  root: RootLayout | undefined,
  searchRoutes: SearchRouteMetadata[]
): Promise<LoaderResult> {
  if (hasMixedLoaderModes(route)) {
    return runMixedLoaders(route, ctx);
  }
  if (resolveDocumentMode(route) === "ssr") {
    return runLoaders(route, ctx);
  }

  const result = hasRequestLoader(route)
    ? await runPprPublicLoaders(route, ctx, currentInstance().buildId, root, searchRoutes)
    : await runPublicLoaders(route, ctx);
  if (result.type !== "data" || !hasRequestLoader(route)) {
    return result;
  }
  return withRequestLoaderData(route, ctx, result);
}

async function serializeLoaderDataResponse(
  result: LoaderResult,
  route: ResolvedRoute,
  requestUrl: string,
  routeContext: RouteDataContext
): Promise<Response> {
  if (result.type === "redirect") {
    const { prefix } = currentInstance();
    const pageUrl = new URL(requestUrl);
    pageUrl.pathname = physicalPath(prefix, pageUrl.pathname);
    return serializeNavigationRedirect(result.response, pageUrl, prefix);
  }
  if (result.type === "not-found") {
    const serialized = await toCrossJSONAsync({
      __furinNotFound: { data: result.error.data, message: result.error.message },
      __furinStatus: 404,
    });
    return new Response(`${JSON.stringify(serialized)}\n`, {
      headers: { "content-type": "application/x-ndjson" },
      status: 200,
    });
  }
  if (result.type === "error") {
    return createRouteDataErrorResponse(result.error, result.message, result.status, routeContext);
  }

  const syncDataWithTitle = withResolvedHead(route, result.syncData);
  if (result.deferredPromises !== undefined) {
    return new Response(
      createDeferredRouteFrameStream(syncDataWithTitle, result.deferredPromises),
      {
        headers: {
          ...result.headers,
          "content-type": "application/x-furin-route",
        },
      }
    );
  }
  const hasRsc = containsRscSource(syncDataWithTitle);
  const body = await serializeLoaderDataNdjson(syncDataWithTitle, undefined);
  emitSerializedPayload(body, hasRsc ? "rsc" : "route-data", requestUrl);
  return new Response(body, {
    headers: {
      ...result.headers,
      "content-type": hasRsc ? "application/x-furin-route" : "application/x-ndjson",
    },
  });
}

export async function serializeGuardRedirect(
  response: Response,
  request: Request
): Promise<Response> {
  const location = response.headers.get("location");
  if (!location) {
    return response;
  }
  const requestUrl = new URL(request.url);
  const prefix = requestUrl.pathname.slice(0, -"/_furin/data".length);
  const rawPath = requestUrl.searchParams.get("path");
  const logicalPath = rawPath ? parseDataEndpointPath(rawPath) : undefined;
  const pageUrl = logicalPath
    ? new URL(prefix + logicalPath.pathname + logicalPath.url.search, requestUrl)
    : requestUrl;

  return await serializeNavigationRedirect(response, pageUrl, prefix);
}

async function serializeNavigationRedirect(
  response: Response,
  pageUrl: URL,
  prefix: string
): Promise<Response> {
  const location = response.headers.get("location");
  if (!location) {
    return response;
  }
  const target = new URL(location, pageUrl);
  const withinMount =
    prefix === "" || target.pathname === prefix || target.pathname.startsWith(`${prefix}/`);
  const href =
    target.origin === pageUrl.origin && withinMount
      ? (target.pathname.slice(prefix.length) || "/") + target.search + target.hash
      : target.href;
  const serialized = await toCrossJSONAsync({ __furinRedirect: href });
  const headers = new Headers(response.headers);
  headers.delete("content-length");
  headers.delete("location");
  headers.set("content-type", "application/x-ndjson");
  headers.set("cache-control", "private, no-store");
  return new Response(`${JSON.stringify(serialized)}\n`, { headers });
}

function navigationDataCacheControl(route: ResolvedRoute): string {
  if (resolveDocumentMode(route) === "ssg") {
    return "public, max-age=0, must-revalidate, s-maxage=31536000";
  }
  const revalidate = resolveDocumentRevalidate(route) ?? 60;
  return `public, max-age=0, s-maxage=${revalidate}, stale-while-revalidate=${revalidate}`;
}

function applyNavigationDataCache(
  response: Response,
  result: LoaderResult,
  route: ResolvedRoute,
  requestUrl: string
): Response {
  const cacheable =
    !IS_DEV &&
    resolveDocumentMode(route) !== "ssr" &&
    !hasRequestLoader(route) &&
    result.type === "data" &&
    result.deferredPromises === undefined;
  if (!cacheable) {
    response.headers.set("cache-control", "private, no-store");
    response.headers.delete("cache-tag");
    return response;
  }

  const { pathname } = new URL(requestUrl);
  response.headers.set("cache-tag", pathname);
  response.headers.set("cache-control", navigationDataCacheControl(route));
  return response;
}

async function createLoaderDataResponse(
  result: LoaderResult,
  route: ResolvedRoute,
  requestUrl: string,
  routeContext: RouteDataContext
): Promise<Response> {
  const response = await serializeLoaderDataResponse(result, route, requestUrl, routeContext);
  return applyNavigationDataCache(response, result, route, requestUrl);
}

/** Serialise navigation data after Elysia has run the matched page's hooks. */
export async function renderRouteData(
  route: ResolvedRoute,
  ctx: Context,
  root: RootLayout,
  searchRoutes: SearchRouteMetadata[],
  logicalHref: string
): Promise<Response> {
  const logicalContext = Object.create(ctx, {
    path: { enumerable: true, value: new URL(logicalHref, ctx.request.url).pathname },
  }) as Context;
  const result = await runDataEndpointLoaders(route, logicalContext, root, searchRoutes);
  return createLoaderDataResponse(
    result,
    route,
    new URL(logicalHref, ctx.request.url).href,
    logicalContext
  );
}

async function createRouteDataErrorResponse(
  error: unknown,
  message: string,
  status: number,
  routeContext: RouteDataContext | undefined
): Promise<Response> {
  const __furinError = { digest: computeErrorDigest(error), message, status };
  const payload = routeContext
    ? {
        __furinError,
        params: routeContext.params,
        path: routeContext.path,
        query: routeContext.query,
      }
    : { __furinError };
  const serialized = await toCrossJSONAsync(payload);
  return new Response(`${JSON.stringify(serialized)}\n`, {
    headers: { "content-type": "application/x-ndjson" },
    status,
  });
}

async function resolveDataRoute(
  route: ResolvedRoute,
  resolveRoute: DataRouteResolver
): Promise<{ route: ResolvedRoute; root: RootLayout | undefined } | Response> {
  try {
    return await resolveRoute(route);
  } catch (error) {
    getLogger().error(error instanceof Error ? error : new Error(String(error)));
    if (IS_DEV) {
      reportDevRouteFailure(error, route);
    }
    return createRouteDataErrorResponse(error, "Something went wrong", 500, undefined);
  }
}

async function resolveDataRoutes(
  routesSource: DataResolvedRoutesSource,
  request: Request
): Promise<ResolvedRoute[] | Response> {
  try {
    return typeof routesSource === "function" ? await routesSource(request) : routesSource;
  } catch (error) {
    getLogger().error(error instanceof Error ? error : new Error(String(error)));
    return createRouteDataErrorResponse(error, "Something went wrong", 500, undefined);
  }
}

function resolvedSearchRoutes(
  routes: ResolvedRoute[],
  matchedRoute: ResolvedRoute,
  currentRoute: ResolvedRoute,
  searchRoutes: SearchRouteMetadata[],
  refreshDevRoute: RefreshDevRoute | undefined
): SearchRouteMetadata[] {
  if (refreshDevRoute === undefined) {
    return searchRoutes;
  }
  return createSearchRouteMetadata(
    routes.map((route) => (route === matchedRoute ? currentRoute : route))
  );
}

/** @internal Handles a production SSG route — sets ETags, Cache-Control, and Cache-Tag. */
async function handleSSGRequest(
  route: ResolvedRoute,
  ctx: Context,
  root: RootLayout,
  buildId: string,
  searchRoutes: SearchRouteMetadata[] | undefined
): Promise<unknown> {
  const { origin } = new URL(ctx.request.url);
  const params = ctx.params ?? {};
  const externalPrerender = isExternalPrerenderRequest(ctx.request);
  const runtimeResult = externalPrerender
    ? {
        cacheStored: true,
        entry: await prerenderRoute(
          route,
          params,
          root,
          origin,
          "ssg",
          undefined,
          searchRoutes,
          ctx
        ),
      }
    : await prerenderRuntimeSSG(route, params, root, origin, buildId, searchRoutes);
  const { cacheStored, entry } = runtimeResult;

  // Loader issued a redirect — forward it directly to the client.
  if (entry instanceof Response) {
    return entry;
  }

  ctx.set.status = entry.status;

  const resolvedPath = resolvePath(route.pattern, params);

  // ETag: "buildId:cachedAt" — unique per render cycle, changes after revalidatePath
  const etag = buildId ? `"${buildId}:${entry.cachedAt}"` : null;
  if (entry.status === 200 && etag && ctx.request.headers.get("if-none-match") === etag) {
    ctx.set.status = 304;
    return;
  }

  ctx.set.headers["content-type"] = "text/html; charset=utf-8";
  // Browser: max-age=0 + must-revalidate → always validates via ETag (304 = free)
  // CDN:     s-maxage=31536000 → cache for 1 year, purge via revalidatePath + purger
  ctx.set.headers["cache-control"] =
    cacheStored && entry.status === 200
      ? "public, max-age=0, must-revalidate, s-maxage=31536000"
      : "no-store";
  if (etag) {
    ctx.set.headers.etag = etag;
  }
  ctx.set.headers["cache-tag"] = resolvedPath;
  return injectSyncRuntimeScript(entry.html);
}

export function createRoutePlugin(
  route: ResolvedRoute,
  root: RootLayout,
  buildId?: string,
  searchRoutes?: SearchRouteMetadata[]
): AnyElysia {
  const resolvedBuildId = buildId ?? "";
  const { pattern, routeChain } = route;

  // Keep every route-chain schema in Elysia's native merge pipeline so its
  // coercion and default semantics remain authoritative for document requests.
  const plugin = routeChain.reduce<AnyElysia>((app, entry) => {
    if (!(entry.params || entry.query)) {
      return app;
    }
    return app.guard({
      params: entry.params as FurinSchema,
      query: entry.query as FurinSchema,
      schema: "merge",
    });
  }, new Elysia());

  plugin.get(pattern, (ctx: Context) =>
    renderResolvedRoute(route, ctx, root, resolvedBuildId, searchRoutes)
  );

  return plugin;
}

export function renderResolvedRoute(
  route: ResolvedRoute,
  ctx: Context,
  root: RootLayout,
  buildId: string,
  searchRoutes: SearchRouteMetadata[] | undefined
): unknown {
  // Dev mode: re-imports page + layouts on every request via the
  // ?furin-server cache-buster. Only loader output is cached in dev; HTML is
  // always reassembled with the latest Bun client chunk URL.
  if (IS_DEV) {
    return handleDevRequest(route, ctx, root, searchRoutes);
  }

  const documentMode = resolveDocumentMode(route);
  if (documentMode === "ssr") {
    return renderSSR(route, ctx, root, undefined, searchRoutes);
  }

  if (hasRequestLoader(route)) {
    return renderPprRoute(route, ctx, root, buildId, searchRoutes);
  }

  if (documentMode === "ssg") {
    return handleSSGRequest(route, ctx, root, buildId, searchRoutes);
  }

  if (documentMode === "isr") {
    ctx.set.headers["cache-tag"] = resolvePath(route.pattern, ctx.params ?? {});
    return handleISR(route, ctx, root, buildId, searchRoutes);
  }

  return renderSSR(route, ctx, root, undefined, searchRoutes);
}

/**
 * Elysia plugin that handles `GET /_furin/data?path=<logicalHref>`.
 *
 * Returns route-frame loader data for successful routes. Deferred routes stream
 * the initial sync frame first, then append one frame batch per settled Promise.
 * SPA navigation calls this endpoint via `parseDeferredNdjson`, which supports
 * both route frames and legacy NDJSON sentinels.
 *
 * Special fields emitted alongside data:
 *   - `__furinStatus: 404` — when the loader called `notFound()`
 *   - `__furinNotFound`    — not-found payload
 *   - `__furinRedirect`    — logical path after a server-side redirect
 */
export function createDataEndpoint(
  routesSource: DataResolvedRoutesSource,
  root?: RootLayout,
  refreshDevRoute?: RefreshDevRoute
): AnyElysia {
  const plugin = new Elysia();
  let matchedRoutes = Array.isArray(routesSource) ? routesSource : [];
  let matchRoute = buildRouteMatcher(matchedRoutes);
  let searchRoutes = createSearchRouteMetadata(matchedRoutes);
  const resolveRoute: DataRouteResolver =
    refreshDevRoute ?? ((route: ResolvedRoute) => Promise.resolve({ root, route }));

  plugin.get(
    "/_furin/data",
    {
      // The transport path is validated below without requiring a TypeBox schema.
    },
    async (ctx) => {
      const rawPath = ctx.query.path;
      if (!rawPath || typeof rawPath !== "string") {
        return problem("Bad Request", { detail: "Missing required query param: path" });
      }

      const parsed = parseDataEndpointPath(rawPath);
      if (!parsed) {
        return problem("Bad Request", { detail: "Invalid path" });
      }
      const { url, pathname } = parsed;

      // Rewrite the request-scoped wide event so logs / drains report the
      // *logical* path the user navigated to (e.g. "/board/123/card/456")
      // instead of the technical "/_furin/data" transport URL. We set this
      // before the route-match check so 404s also surface the attempted path
      // — otherwise monitoring just sees "GET /_furin/data 404" with no clue.
      const wideEventLog = getLogger();
      wideEventLog.set({ path: rawPath });

      const currentRoutes = await resolveDataRoutes(routesSource, ctx.request);
      if (currentRoutes instanceof Response) {
        return currentRoutes;
      }
      if (currentRoutes !== matchedRoutes) {
        matchedRoutes = currentRoutes;
        matchRoute = buildRouteMatcher(matchedRoutes);
        searchRoutes = createSearchRouteMetadata(matchedRoutes);
      }
      const matched = matchRoute(pathname);

      if (!matched) {
        return problem("Not Found", { detail: "Route not found" });
      }

      // Now that we know the matched pattern, add it as a stable aggregation
      // key for drains (e.g. "p99 latency by route").
      wideEventLog.set({ routePattern: matched.route.pattern });

      const current = await resolveDataRoute(matched.route, resolveRoute);
      if (current instanceof Response) {
        return current;
      }
      const currentSearchRoutes = resolvedSearchRoutes(
        matchedRoutes,
        matched.route,
        current.route,
        searchRoutes,
        refreshDevRoute
      );

      // Build a synthetic Elysia-compatible context for the matched route.
      // Loaders receive request, params, query, set, headers, and cookie.
      // Build the synthetic URL from the parsed `pathname + search` only —
      // never from `rawPath` directly — so an attacker cannot smuggle a
      // foreign origin into `syntheticRequest.url`.
      // Forward the real request headers (cookies, auth) so loaders reading
      // `request.headers` behave the same during SPA navigation as in SSR.
      const syntheticRequest = new Request(new URL(pathname + url.search, ctx.request.url), {
        headers: ctx.request.headers,
      });
      const syntheticSet = { headers: {} as Record<string, string>, status: 200 as number };
      const syntheticCtx: SyntheticDataContext = {
        cookie: ctx.cookie,
        headers: ctx.headers,
        params: matched.params,
        path: pathname,
        query: Object.fromEntries(url.searchParams),
        // Loader-emitted redirects flow through `runLoaders` → `result.type
        // === "redirect"` and are converted to NDJSON below. The Response we
        // return here only has to be detectable by that pipeline.
        redirect: (location: string, status?: number) =>
          new Response(null, { headers: { location }, status: status ?? 302 }),
        request: syntheticRequest,
        set: syntheticSet,
        // Synthetic `status` helper: numeric codes only. Callers that reach
        // this endpoint never dispatch a string-keyed status; rejecting them
        // is safer than coercing via `Number(code)` and silently producing
        // `NaN`.
        status: (code: number) => new Response(null, { status: code }),
      } as unknown as SyntheticDataContext;

      // Normalize params and query through the route chain schemas so SPA and
      // document requests expose identical typed/defaulted inputs.
      const mergedParams = mergeRouteSchemas(current.route.routeChain, "params");
      const mergedQuery = mergeRouteSchemas(current.route.routeChain, "query");
      const parsedParams = await parseRouteParams(matched.params, mergedParams);
      if (!parsedParams.ok) {
        return problem(422, { detail: "Invalid params", errors: parsedParams.errors });
      }
      const parsedQuery = await parseRouteQuery(url, mergedQuery);
      if (!parsedQuery.ok) {
        return problem(422, { detail: "Invalid query", errors: parsedQuery.errors });
      }
      syntheticCtx.params = parsedParams.params;
      syntheticCtx.query = parsedQuery.query as SearchParamsInput;

      const result = await runDataEndpointLoaders(
        current.route,
        syntheticCtx as unknown as Context,
        current.root,
        currentSearchRoutes
      );

      return createLoaderDataResponse(result, current.route, syntheticRequest.url, syntheticCtx);
    }
  );

  return plugin;
}

/**
 * Runs the matched page's `head()` against the resolved sync data and, when it
 * yields a title, returns a copy of `syncData` carrying the reserved
 * `__furinTitle` field. `head()` never executes in the browser, so this is the
 * only channel through which SPA navigation can learn the new document title.
 *
 * Deferred fields are absent from `syncData` (they are still Promises), so a
 * `head()` that reads one sees `undefined` — titles should be derived from
 * synchronous loader data. A throwing `head()` is swallowed: a missing title
 * must never break the data response.
 */
function withResolvedHead(
  route: ResolvedRoute,
  syncData: Record<string, unknown>
): Record<string, unknown> {
  const { head } = route.page;
  if (!head) {
    return syncData;
  }
  let headOptions: HeadOptions;
  try {
    headOptions = head(syncData);
  } catch {
    return syncData;
  }
  const title = extractTitle(headOptions.meta);
  let includeHead = false;
  try {
    includeHead =
      new TextEncoder().encode(JSON.stringify(headOptions)).byteLength <= MAX_NAVIGATION_HEAD_BYTES;
  } catch {
    // Invalid or cyclic metadata must not break an otherwise valid navigation.
  }
  return {
    ...syncData,
    ...(includeHead ? { __furinHead: headOptions } : {}),
    ...(title === undefined ? {} : { __furinTitle: title }),
  };
}

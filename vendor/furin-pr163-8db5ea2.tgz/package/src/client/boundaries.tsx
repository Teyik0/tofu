import { Component, Fragment, type ReactNode } from "react";
import { computeErrorDigest } from "../shared/digest.ts";
import { type ErrorComponent, getPublicErrorMessage } from "../shared/error.ts";
import { isNotFoundError, type NotFoundComponent } from "../shared/not-found.ts";
import { DefaultErrorFallback, DefaultNotFoundFallback } from "./default-screens.tsx";
import { FurinDocumentFallback } from "./document.tsx";
import { isFurinServerError } from "./server-error.ts";

/**
 * Default HTTP status surfaced to error UIs when the caught error has no
 * intrinsic status (e.g. a thrown `Error`, a non-Error throw). The loader
 * pipeline produces a `FurinServerError` with the right status when a thrown
 * `Response` is the cause; everything else collapses to 500.
 */
const DEFAULT_ERROR_STATUS = 500;

const SERVER_RESET_NOOP = () => {
  /* reset is a client-only action; on the server the response is already committed */
};

function getServerDigest(error: unknown): string | undefined {
  if (isFurinServerError(error)) {
    return error.digest;
  }
  if ((typeof error !== "object" && typeof error !== "function") || error === null) {
    return;
  }
  const digest = (error as Error & { __furinDigest?: unknown }).__furinDigest;
  return typeof digest === "string" ? digest : undefined;
}

function normalizeCaughtError(error: unknown): Error {
  if (error instanceof Error) {
    return error;
  }
  const normalized = new Error(String(error));
  if ((typeof error === "object" && error !== null) || typeof error === "function") {
    Object.defineProperties(normalized, Object.getOwnPropertyDescriptors(error));
  }
  return normalized;
}

interface ErrorBoundaryProps {
  children: ReactNode;
  /**
   * Server-provided digest for an error rendered server-side. Honoured only
   * for the FIRST error this boundary surfaces post-hydration — i.e. when the
   * latched error is plausibly the same one the server already logged. After
   * any reset, or when subsequent client-side errors are caught, the boundary
   * computes a fresh digest from the actual caught error so distinct failures
   * keep distinct IDs.
   */
  digest?: string;
  /** @internal Preserve a valid document when the outer root boundary catches. */
  document?: boolean;
  /** Component rendered when an error is caught. Omit to use the built-in default. */
  fallback?: ErrorComponent;
  /**
   * Invoked AFTER the boundary has cleared its local error state. Slice 7
   * wires this to `router.navigate(currentHref, { force: true })` so the
   * loader re-runs.
   */
  onReset?: () => void;
  /**
   * When this value changes the boundary clears its error state, effectively
   * retrying the render of `children`. Slice 7 drives this from router
   * navigation success.
   */
  resetKey?: string | number;
}

interface ErrorBoundaryState {
  /**
   * Digest preserved from a server error or computed when the error was
   * latched. Stored in state so each distinct caught error gets its own ID,
   * instead of all of them inheriting the server-provided `digest` prop.
   */
  digest: string | null;
  /** Unmount/remount counter — bumped on reset to force React to discard
   *  the previous subtree (including any broken state). */
  epoch: number;
  error: Error | null;
}

/**
 * Catches generic errors thrown during render of `children`. Lets
 * `FurinNotFoundError` bubble past so a sibling `<FurinNotFoundBoundary>`
 * can handle it.
 *
 * Must be a class: React error catching (`getDerivedStateFromError`,
 * `componentDidCatch`) has no function-component equivalent.
 */
export class FurinErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state: ErrorBoundaryState = {
    digest: null,
    epoch: 0,
    error: null,
  };

  static getDerivedStateFromError(error: unknown): Partial<ErrorBoundaryState> {
    // Preserve server digests carried by SPA error sentinels or deferred
    // rejections. Otherwise compute one right at catch-time so the value is
    // anchored to this specific error instance across re-renders.
    return {
      digest: getServerDigest(error) ?? computeErrorDigest(error),
      error: normalizeCaughtError(error),
    };
  }

  override componentDidCatch(error: Error): void {
    if (import.meta.hot && typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent("furin:client-error", {
          detail: { error, phase: "client-render" },
        })
      );
    }
  }

  override componentDidUpdate(prevProps: ErrorBoundaryProps) {
    if (prevProps.resetKey !== this.props.resetKey && this.state.error) {
      this.setState((state) => ({ digest: null, epoch: state.epoch + 1, error: null }));
    }
  }

  reset = () => {
    // setState is async; running onReset BEFORE the state has actually flipped
    // would expose stale `state.error` to anything the callback transitively
    // reads (e.g. router.refresh re-rendering this very subtree). The second
    // argument to setState fires after the commit, which is what we want.
    this.setState(
      (s) => ({ digest: null, epoch: s.epoch + 1, error: null }),
      () => {
        this.props.onReset?.();
      }
    );
  };

  override render(): ReactNode {
    const { error, epoch, digest } = this.state;
    if (error) {
      // notFound() is a control-flow signal — bubble it up to the nearest
      // FurinNotFoundBoundary rather than displaying an error UI for it.
      if (isNotFoundError(error)) {
        throw error;
      }
      const Fallback = this.props.fallback ?? DefaultErrorFallback;
      // Digest precedence:
      //   1. A server digest — carried by an SPA error sentinel or serialized
      //      deferred rejection so logs correlate without recomputing a
      //      different hash from a sanitized error and synthetic stack.
      //   2. state.digest — preserved or computed at catch time for the
      //      actual caught error.
      //   3. props.digest — the server-rendered digest, only meaningful for
      //      the very first error post-hydration; we still honour it as a
      //      last-resort fallback in case state.digest is somehow missing
      //      (e.g. tests that inject state by hand).
      //   4. recompute on the spot — defensive, should never be reached.
      const serverDigest = getServerDigest(error);
      const finalDigest = serverDigest ?? digest ?? this.props.digest ?? computeErrorDigest(error);
      const message = this.props.fallback ? error.message : getPublicErrorMessage(error);
      // Status precedence: FurinServerError carries the original Response.status
      // (or the loader's computed 500 for non-Response throws); everything else
      // collapses to the default 500.
      const status = isFurinServerError(error) ? error.status : DEFAULT_ERROR_STATUS;
      const fallback = (
        <Fallback
          error={{ digest: finalDigest, message, status }}
          reset={typeof window === "undefined" ? SERVER_RESET_NOOP : this.reset}
        />
      );
      return this.props.document ? (
        <FurinDocumentFallback>{fallback}</FurinDocumentFallback>
      ) : (
        fallback
      );
    }
    // The `key` trick ensures that after a reset, children remount fresh
    // rather than retaining stale state from the failed render.
    return <Fragment key={epoch}>{this.props.children}</Fragment>;
  }
}

interface NotFoundBoundaryProps {
  children: ReactNode;
  fallback?: NotFoundComponent;
  resetKey?: string | number;
}

interface NotFoundBoundaryState {
  epoch: number;
  error: Error | null;
}

/**
 * Catches `FurinNotFoundError` (thrown by `notFound()`) and renders the
 * nearest not-found UI. Generic errors are re-thrown from render() so a
 * parent `<FurinErrorBoundary>` can handle them.
 *
 * Must be a class: React error catching has no function-component equivalent.
 */
// biome-ignore lint/style/useReactFunctionComponents: React error boundaries require a class component.
export class FurinNotFoundBoundary extends Component<NotFoundBoundaryProps, NotFoundBoundaryState> {
  override state: NotFoundBoundaryState = { epoch: 0, error: null };

  static getDerivedStateFromError(error: Error): Partial<NotFoundBoundaryState> {
    return { error };
  }

  override componentDidUpdate(prevProps: NotFoundBoundaryProps) {
    if (prevProps.resetKey !== this.props.resetKey && this.state.error) {
      this.setState((s) => ({ epoch: s.epoch + 1, error: null }));
    }
  }

  override render(): ReactNode {
    const { error, epoch } = this.state;
    if (error) {
      if (!isNotFoundError(error)) {
        throw error;
      }
      const Fallback = this.props.fallback ?? DefaultNotFoundFallback;
      return <Fallback error={{ data: error.data, message: error.message }} />;
    }
    return <Fragment key={epoch}>{this.props.children}</Fragment>;
  }
}

/**
 * Options passed to `wrapSegmentBoundaries` when running on the client.
 * The server path omits them entirely.
 */
export interface BoundaryOptions {
  onReset?: () => void;
  resetKey?: string | number;
}

/**
 * Minimal shape of a segment boundary descriptor, accepted by both server-side
 * `SegmentBoundary` and client-side `ClientSegmentBoundary`.
 */
export interface SegmentBoundaryLike {
  error?: ErrorComponent;
  notFound?: NotFoundComponent;
}

/**
 * Wraps `inner` with the boundary pair declared at a single segment depth.
 *
 * The ordering is deliberate and MUST be kept identical on server **and**
 * client so that hydration sees the exact same React tree:
 *
 *   <FurinErrorBoundary>
 *     <FurinNotFoundBoundary>{inner}</FurinNotFoundBoundary>
 *   </FurinErrorBoundary>
 *
 * `FurinErrorBoundary` is OUTSIDE because it re-throws `FurinNotFoundError`
 * during render, allowing an ancestor not-found boundary to catch it. Placing
 * the not-found boundary inside would mean the same-depth error boundary
 * catches a `notFound()` throw first, latches onto it, and the re-throw would
 * not find a `NotFoundBoundary` deeper than itself — it needs one higher up.
 *
 * @param inner    - React subtree to wrap.
 * @param segment  - Boundary descriptor for this depth (may be undefined).
 * @param options  - Optional client-side reset options (ignored on server).
 * @returns The wrapped React node.
 */
export function wrapSegmentBoundaries(
  inner: ReactNode,
  segment: SegmentBoundaryLike | undefined,
  options: BoundaryOptions | undefined
): ReactNode {
  if (!segment) {
    return inner;
  }

  let wrapped: ReactNode = inner;

  if (segment.notFound) {
    wrapped = (
      <FurinNotFoundBoundary fallback={segment.notFound} resetKey={options?.resetKey}>
        {wrapped}
      </FurinNotFoundBoundary>
    );
  }

  if (segment.error) {
    wrapped = (
      <FurinErrorBoundary
        fallback={segment.error}
        onReset={options?.onReset}
        resetKey={options?.resetKey}
      >
        {wrapped}
      </FurinErrorBoundary>
    );
  }

  return wrapped;
}

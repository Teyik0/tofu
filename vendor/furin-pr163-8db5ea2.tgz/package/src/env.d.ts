// Global type declarations shipped by Furin.
// Referenced automatically via furin-env.d.ts — no user config needed.

declare module "*.css" {}
declare module "*.svg" {
  const src: string;
  export default src;
}
declare module "*.png" {
  const src: string;
  export default src;
}
declare module "*.jpg" {
  const src: string;
  export default src;
}
declare module "*.jpeg" {
  const src: string;
  export default src;
}
declare module "*.gif" {
  const src: string;
  export default src;
}
declare module "*.webp" {
  const src: string;
  export default src;
}
declare module "*.avif" {
  const src: string;
  export default src;
}
declare module "*.ico" {
  const src: string;
  export default src;
}
declare module "*.woff" {
  const src: string;
  export default src;
}
declare module "*.woff2" {
  const src: string;
  export default src;
}
declare module "*.mdx" {
  import type { ComponentType, ElementType } from "react";

  const MDXComponent: ComponentType<{ components?: { [tag: string]: ElementType } }>;
  export default MDXComponent;
}

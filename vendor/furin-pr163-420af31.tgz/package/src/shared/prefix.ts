// Naming helpers shared between the runtime (furin.ts) and the build
// pipeline (adapter/bun.ts) — both must agree on where a mounted app's
// client assets live on disk.

const FILESYSTEM_DISTINCTIONS_RE = /%[\dA-F]{2}|[-.*A-Z]/g;

/**
 * On-disk client dir name for a mounted app: the root instance keeps the
 * historical `client/`, prefixed instances get `client-<slug>/` next to it.
 */
export function clientDirNameForPrefix(prefix: string): string {
  return prefix === "" ? "client" : `client-${prefixSlug(prefix)}`;
}

/** Canonical deployed path, shared by routing, PPR state and cache invalidation. */
export function physicalPath(prefix: string, path: string): string {
  if (prefix === "") {
    return path;
  }
  return path === "/" ? prefix : `${prefix}${path}`;
}

/** Whether `pathname` lies under `prefix` on a path-segment boundary. */
export function isWithinPrefix(pathname: string, prefix: string): boolean {
  return (
    prefix === "" ||
    pathname === prefix ||
    (pathname.startsWith(prefix) && pathname.charCodeAt(prefix.length) === 47)
  );
}

/** Filesystem-safe slug for a mount prefix (`/admin/v2` → `admin-v2`). */
export function prefixSlug(prefix: string): string {
  return prefix
    .slice(1)
    .split("/")
    .map((segment) =>
      encodeURIComponent(segment).replace(FILESYSTEM_DISTINCTIONS_RE, (character) =>
        character.startsWith("%")
          ? character
          : `%${character.charCodeAt(0).toString(16).toUpperCase()}`
      )
    )
    .join("-");
}

/**
 * Route ids carry their mount's prefix (`defineRoute("/admin/users")`), so a
 * pages directory validates for one mount only.
 */
export function assertOnePagesDirPerMount(
  mounts: readonly { pagesDir: string; prefix: string }[]
): void {
  const byPagesDir = new Map<string, string>();
  for (const { pagesDir, prefix } of mounts) {
    const existing = byPagesDir.get(pagesDir);
    if (existing !== undefined && existing !== prefix) {
      throw new Error(
        `[furin] pagesDir "${pagesDir}" is mounted under both prefix "${existing || "/"}" and prefix "${prefix || "/"}". Route ids carry their mount's prefix, so one pages directory serves one mount: give each mount its own pages directory.`
      );
    }
    byPagesDir.set(pagesDir, prefix);
  }
}

/**
 * Validate generated directory identities before writing any artifacts.
 */
export function assertNoPrefixSlugCollisions(prefixes: string[]): void {
  const byDirName = new Map<string, string>();
  for (const prefix of prefixes) {
    const dirName = clientDirNameForPrefix(prefix);
    const existing = byDirName.get(dirName);
    if (existing !== undefined && existing !== prefix) {
      throw new Error(
        `[furin] prefixes "${existing}" and "${prefix}" both map to the client directory ` +
          `"${dirName}" — rename one of them so their slugs (\`/\` → \`-\`) no longer collide.`
      );
    }
    byDirName.set(dirName, prefix);
  }
}

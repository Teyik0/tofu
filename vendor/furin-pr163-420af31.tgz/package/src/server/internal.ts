import type { AnyElysia } from "elysia";
import type { ClientPreloadManifest } from "../build/preload-manifest.ts";
import type { SsgCacheEntry } from "./cache/index.ts";
import {
  hasPendingISRRevalidations as hasPendingISR,
  waitForPendingISRRevalidations as waitForPendingISR,
} from "./cache/isr.ts";
import { setCacheTagPurger as installCacheTagPurger } from "./cache/purger.ts";
import {
  type RuntimeCacheProvider,
  setRuntimeCacheProvider as setCacheProvider,
} from "./cache/runtime-cache.ts";
import { setRuntimeEvlogWaitUntil as installRuntimeEvlogWaitUntil } from "./evlog.ts";
import { markExternalPrerenderRequest as markExternalPrerender } from "./external-prerender.ts";
import { __clearInstanceRegistry } from "./instance.ts";
import { type AppPrerender, collectPrerenders as collect } from "./prerender.ts";
import { restorePprResumeRequest as restoreResumeRequest } from "./render/ppr-request.ts";

// ── Compile-time context for compiled binaries ──────────────────────────────
// The generated compile entry calls `__setCompileContext()` before importing
// server.ts. At runtime, `router.ts` and `furin.ts` use `getCompileContext()`
// to resolve modules and assets from the binary instead of the filesystem.

export interface EmbeddedAppData {
  clientDir: string;
  publicDir?: string;
}

/** Namespace of a bundled page, layout or convention module. */
export interface CompiledModule {
  /** Convention component (`error.tsx`, `not-found.tsx`). */
  readonly default?: unknown;
  /** `defineRoute(id)` export of a page or layout. */
  readonly route?: unknown;
}

/**
 * What a deployment platform provides. Adapters declare these once; the build
 * and the production runtime read them instead of naming a platform.
 */
export interface AdapterCapabilities {
  /**
   * Who serves `/_client/*` and `public/` files: Furin from disk, Furin from
   * files embedded in a standalone executable, or the platform before
   * requests reach Elysia.
   */
  readonly assets: "filesystem" | "embedded" | "platform";
  /**
   * Who caches public SSG, ISR and PPR pages: Furin (process memory or
   * `furin({ pageCache })`) or the platform's own cache.
   */
  readonly publicCache: "framework" | "platform";
  /**
   * Whether requests arrive through `Bun.serve()`, so browser events can
   * upgrade to a WebSocket. Platforms invoking `app.handle(Request)` use SSE.
   */
  readonly websocket: boolean;
}

/** Deployment adapter a production build was made for. */
export interface CompileContextAdapter {
  readonly capabilities: AdapterCapabilities;
  readonly name: string;
}

export interface CompileContextRoute {
  mode: "ssr" | "ssg" | "isr";
  path: string;
  pattern: string;
}

export interface CompileContext {
  /** Absent when the host application owns deployment (package builds). */
  adapter?: CompileContextAdapter;
  buildId?: string;
  /** Runtime directory containing this app's disk-served client assets. */
  clientDir?: string;
  /** Whether the emitted hydration client sends browser log batches. */
  clientLogging?: boolean;
  embedded?: EmbeddedAppData;
  /** Bundled route modules, keyed by their absolute posix source path. */
  modules: { readonly [path: string]: CompiledModule };
  /** Elysia-native route tree generated for this mounted app. */
  nativeRoutes?: AnyElysia;
  /** Mount prefix this app was built for (`""` = root). */
  prefix?: string;
  /** Chunk URLs to modulepreload, produced by the client build. */
  preloadManifest?: ClientPreloadManifest;
  /** Root-level conventions discovered at compile time. */
  rootConventions?: { errorPath?: string; notFoundPath?: string };
  rootPath: string;
  /** Per-route metadata including pre-computed segment boundaries. */
  routeMetadata?: Record<
    string,
    {
      requestKeys?: string[];
      requestKeysByLoader?: string[][];
      segmentBoundaries: Array<{
        depth: number;
        path: string;
        errorPath?: string;
        notFoundPath?: string;
      }>;
    }
  >;
  routes: CompileContextRoute[];
  ssgCache?: Record<string, SsgCacheEntry>;
  /** Production HTML template embedded by filesystem-free deployment adapters. */
  templateHtml?: string;
}

export function waitForPendingISRRevalidations(): Promise<void> {
  return waitForPendingISR();
}

export function hasPendingISRRevalidations(): boolean {
  return hasPendingISR();
}

export function markExternalPrerenderRequest(request: Request): Request {
  return markExternalPrerender(request);
}

export function setRuntimeCacheProvider(provider: RuntimeCacheProvider): void {
  setCacheProvider(provider);
}

export const setRuntimeEvlogWaitUntil = installRuntimeEvlogWaitUntil;

export function setCacheTagPurger(purger: (tags: string[]) => Promise<void>): void {
  installCacheTagPurger(purger);
}

export const restorePprResumeRequest = restoreResumeRequest;

/** Build-time prerender pass, run by the build inside the production bundle. */
export function collectPrerenders(render: boolean): Promise<AppPrerender[]> {
  return collect(render);
}

// Contexts are keyed by (pagesDir, prefix) — pagesDir being the directory
// containing root.tsx, normalized to posix separators. The SAME pagesDir may
// legally be mounted under two different prefixes (assertPrefixAvailable only
// rejects same-prefix collisions), so pagesDir alone would let the second
// registration overwrite the first. Several packaged furin apps can each ship
// a self-registering module calling `__setCompileContext()` — registration is
// ADDITIVE, one context per (app, mount).
const _compileContexts = new Map<string, CompileContext>();

function normalizeContextKey(path: string): string {
  return path.replaceAll("\\", "/");
}

function pagesDirOf(ctx: CompileContext): string {
  const rootPath = normalizeContextKey(ctx.rootPath);
  const lastSlash = rootPath.lastIndexOf("/");
  return lastSlash === -1 ? rootPath : rootPath.slice(0, lastSlash);
}

// "\u0000" cannot appear in a path or a prefix, so the composite key is
// unambiguous even for pagesDirs containing spaces.
function contextKey(pagesDir: string, prefix: string): string {
  return `${pagesDir}\u0000${prefix}`;
}

export function __setCompileContext(ctx: CompileContext): void {
  _compileContexts.set(contextKey(pagesDirOf(ctx), ctx.prefix ?? ""), ctx);
}

/**
 * Looks up the compile context of a mount. The declared prefix is the mount's
 * build-time identity and is stable across machines, while the absolute
 * pagesDir differs once a binary runs from another cwd: a sole context for
 * the prefix answers, and pagesDir only disambiguates independent apps that
 * share a prefix. A context built for another prefix never answers.
 *
 * Without a mount, route discovery resolves absolute module paths through the
 * module table of the sole compiled app, if exactly one is registered.
 */
export function getCompileContext(pagesDir?: string, prefix?: string): CompileContext | null {
  if (pagesDir === undefined || prefix === undefined) {
    return _compileContexts.size === 1 ? (_compileContexts.values().next().value ?? null) : null;
  }
  const candidates = [..._compileContexts.values()].filter((ctx) => (ctx.prefix ?? "") === prefix);
  if (candidates.length <= 1) {
    return candidates[0] ?? null;
  }
  const exact = _compileContexts.get(contextKey(normalizeContextKey(pagesDir), prefix));
  if (exact) {
    return exact;
  }
  throw new Error(
    `[furin] ${candidates.length} compiled apps are registered for prefix ${JSON.stringify(prefix || "/")} and none was built from ${JSON.stringify(pagesDir)}. Mount each compiled app with the pagesDir it was built from.`
  );
}

/** All registered contexts, keyed by the composite (pagesDir, prefix) key. */
export function getAllCompileContexts(): ReadonlyMap<string, CompileContext> {
  return _compileContexts;
}

export function __resetCompileContext(): void {
  _compileContexts.clear();
  // A test tearing down compile contexts is tearing down its furin mounts —
  // forget their prefix registrations too so the next test mounts cleanly.
  __clearInstanceRegistry();
}

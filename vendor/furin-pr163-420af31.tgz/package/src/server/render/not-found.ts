import { createElement } from "react";
import { type DocumentAssets, FurinDocumentFallback } from "../../client/document.tsx";
import { resolveRouteElement } from "../../client/route-element.tsx";
import { normalizeHref, toLogical } from "../../client/router/link-utils.ts";
import type { RouterContextValue } from "../../client/router/types.ts";
import type { FurinSchema } from "../../shared/elysia-contract.ts";
import { FurinNotFoundError } from "../../shared/not-found.ts";
import { ROUTE_MATCHES_KEY, type SerializedRouteMatch } from "../../shared/route-matches.ts";
import type { SearchParamsInput } from "../../shared/search-params.ts";
import { getLogger } from "../context-logger.ts";
import { currentInstance, isDevelopment } from "../instance.ts";
import { parseRouteQuery } from "../router/schemas.ts";
import type { RootLayout } from "../router/types.ts";
import { useRequestCspNonce } from "../security/csp.ts";
import { streamToString } from "./assemble.ts";
import { withDocumentState } from "./document.tsx";
import { buildNotFoundElement, SERVER_RESET_NOOP } from "./element.tsx";
import { withSSRRouterContext } from "./prepare-render.ts";
import { renderToReadableStream } from "./react-stream.ts";
import { generateIndexHtml } from "./shell.ts";
import {
  documentAssetsFromTemplate,
  getDevDocumentAssets,
  getProductionDocumentAssets,
} from "./template.ts";

/**
 * Renders the root-level not-found component into a complete 404 HTML Response.
 * Used by the Elysia `.error` catch-all when no route matches the request URL.
 */
// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: the catch-all resolves document assets, route context and a safe fallback for an unexecuted root loader.
export async function renderRootNotFound(
  root: RootLayout,
  request: Request | undefined,
  listenerOrigin?: string
): Promise<Response> {
  const productionAssets = getProductionDocumentAssets();
  let assets: DocumentAssets;
  if (isDevelopment() && listenerOrigin) {
    try {
      assets = await getDevDocumentAssets(listenerOrigin);
    } catch {
      assets = documentAssetsFromTemplate(generateIndexHtml());
    }
  } else if (productionAssets === null) {
    assets = documentAssetsFromTemplate(generateIndexHtml());
  } else {
    assets = productionAssets;
  }
  const notFoundError = new FurinNotFoundError(undefined);
  const nonce = request ? useRequestCspNonce(request) : undefined;

  // The request-scope wrap binds the path-resolved instance before this
  // handler runs, so its prefix is the basePath — SSR'd links on the 404
  // page must be physical (prefixed), and currentHref logical, exactly like
  // the regular render pipeline.
  const basePath = currentInstance().prefix;
  const requestUrl = request ? new URL(request.url) : undefined;
  const logicalPath = requestUrl ? normalizeHref(toLogical(requestUrl.pathname, basePath)) : "/";
  let query: SearchParamsInput = {};
  if (requestUrl) {
    const parsedQuery = await parseRouteQuery(
      requestUrl,
      root.route.query as FurinSchema | undefined
    );
    if (parsedQuery.ok) {
      ({ query } = parsedQuery);
    } else {
      const rawQuery = await parseRouteQuery(requestUrl, undefined);
      if (rawQuery.ok) {
        ({ query } = rawQuery);
      }
    }
  }
  const notFoundContext: RouterContextValue = {
    basePath,
    currentHref: logicalPath,
    defaultPreload: "intent",
    defaultPreloadDelay: 50,
    defaultPreloadStaleTime: 30_000,
    invalidatePrefetch: (_path, _type) => {
      /* noop */
    },
    isNavigating: false,
    navigate: (_href, _opts) => Promise.resolve(),
    prefetch: (_href, _opts) => {
      /* noop */
    },
    refresh: (_opts) => Promise.resolve(),
    search: query,
    searchRoutes: [],
  };

  getLogger().set({
    furin: {
      action: "catch_all",
      path: requestUrl?.pathname ?? "/",
      render: "not-found",
    },
  });

  // No page matched, so no loader ran. A root layout that needs loader data
  // cannot render: the not-found then belongs to the root segment and renders
  // inside the minimal document.
  const failure: SerializedRouteMatch = {
    error: { message: notFoundError.message },
    status: "notFound",
  };
  const data = {
    params: {},
    path: logicalPath,
    query,
    [ROUTE_MATCHES_KEY]:
      root.route.loader || root.route.requestLoader
        ? [failure]
        : [{ fields: {}, status: "success" }, failure],
  };
  let reactStream: Awaited<ReturnType<typeof renderToReadableStream>>;
  try {
    reactStream = await renderToReadableStream(
      withDocumentState(
        withSSRRouterContext(
          resolveRouteElement({
            boundaries: [{ depth: 0, error: root.error, notFound: root.notFound }],
            boundaryOptions: undefined,
            chain: [root.route],
            data,
            page: undefined,
            reset: SERVER_RESET_NOOP,
            rootBoundary: root,
          }),
          notFoundContext
        ),
        assets,
        undefined,
        data,
        nonce
      ),
      { nonce }
    );
  } catch (renderError) {
    // The user's not-found component itself threw. Fall back to the built-in
    // screen, but surface the failure — silently swallowing it hides a broken
    // 404 page from logs and drains.
    getLogger().set({
      furin: {
        action: "component_render_failed",
        error: renderError instanceof Error ? renderError.message : String(renderError),
        render: "not-found",
      },
    });
    reactStream = await renderToReadableStream(
      withDocumentState(
        createElement(
          FurinDocumentFallback,
          null,
          withSSRRouterContext(buildNotFoundElement(undefined, notFoundError), notFoundContext)
        ),
        assets,
        undefined,
        data,
        nonce
      ),
      { nonce }
    );
  }
  await reactStream.allReady;
  const html = await streamToString(reactStream);

  return new Response(html, {
    headers: { "Content-Type": "text/html; charset=utf-8" },
    status: 404,
  });
}

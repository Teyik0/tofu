import { type Context, ElysiaStatus, StatusMap } from "elysia";
import { readBoundedBytes } from "../bounded-body.ts";
import type { StoredResponse } from "./adapter.ts";

const NON_REPLAYABLE_HEADERS = new Set([
  "authorization",
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "set-cookie",
  "transfer-encoding",
  "upgrade",
  "www-authenticate",
]);
export const MAX_SYNC_REPLAY_RESPONSE_BYTES = 1024 * 1024;
const UNREPLAYABLE_SYNC_RESPONSE_BODY = new TextEncoder().encode(
  JSON.stringify({
    code: "FURIN_UNREPLAYABLE_SYNC_RESPONSE",
    message:
      "This mutation response cannot be replayed safely. Return a small bounded response or set idempotent: false on the route.",
  })
);

export type StoreResponseResult =
  | { kind: "stored"; response: StoredResponse }
  | { kind: "unreplayable"; response: StoredResponse };

function statusCode(status: Context["set"]["status"]): number {
  if (typeof status === "number") {
    return status;
  }
  return status === undefined ? 200 : StatusMap[status];
}

/** Match Elysia's effective status without interpreting application payload fields. */
export function effectiveResponseStatus(value: unknown, set: Context["set"]): number {
  if (value instanceof ElysiaStatus || (value instanceof Response && value.status !== 200)) {
    return value.status;
  }
  const status = statusCode(set.status);
  return value instanceof Error && status === 200 ? 500 : status;
}

export function effectiveResponseHeaders(
  value: unknown,
  set: Context["set"]
): Context["set"]["headers"] {
  const entries = Object.entries(set.headers);
  if (value instanceof Response) {
    entries.push(...value.headers);
  } else if (value instanceof ElysiaStatus) {
    entries.push(...Object.entries(value.headers ?? {}));
  }
  return Object.fromEntries(entries.map(([name, header]) => [name.toLowerCase(), header]));
}

function replayableHeaders(entries: Iterable<readonly [string, string]>): Headers {
  return new Headers(
    Array.from(entries, ([name, value]): [string, string] => [name, value]).filter(
      ([name]) => !NON_REPLAYABLE_HEADERS.has(name.toLowerCase())
    )
  );
}

function responseHeaders(headers: Context["set"]["headers"]): Headers {
  const result = new Headers();
  for (const [name, value] of Object.entries(headers)) {
    if (value !== undefined && !NON_REPLAYABLE_HEADERS.has(name.toLowerCase())) {
      for (const entry of Array.isArray(value) ? value : [value]) {
        result.append(name, String(entry));
      }
    }
  }
  return result;
}

function storedResponseResult(
  headers: Headers,
  body: Uint8Array,
  status: number
): StoreResponseResult {
  if (body.byteLength > MAX_SYNC_REPLAY_RESPONSE_BYTES) {
    return unreplayable();
  }
  return {
    kind: "stored",
    response: {
      body,
      headers: [...headers.entries()],
      status,
    },
  };
}

function responseContentLength(response: Response): number | undefined {
  const header = response.headers.get("content-length");
  if (header === null) {
    return;
  }
  const parsed = Number(header);
  return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : undefined;
}

async function readBoundedResponseBody(response: Response): Promise<Uint8Array | undefined> {
  if (response.body === null) {
    return new Uint8Array();
  }
  const contentLength = responseContentLength(response);
  if (contentLength === undefined || contentLength > MAX_SYNC_REPLAY_RESPONSE_BYTES) {
    return;
  }

  return await readBoundedBytes(response.body, MAX_SYNC_REPLAY_RESPONSE_BYTES);
}

function unreplayable(): StoreResponseResult {
  return {
    kind: "unreplayable",
    response: {
      body: UNREPLAYABLE_SYNC_RESPONSE_BODY.slice(),
      headers: [["content-type", "application/json;charset=utf-8"]],
      status: 500,
    },
  };
}

export function mergeStoredResponseHeaders(
  storedResponse: StoredResponse,
  headers: Context["set"]["headers"]
): StoredResponse {
  const merged = replayableHeaders(storedResponse.headers);
  for (const [name, value] of Object.entries(headers)) {
    if (value !== undefined && !NON_REPLAYABLE_HEADERS.has(name.toLowerCase())) {
      merged.delete(name);
      for (const entry of Array.isArray(value) ? value : [value]) {
        merged.append(name, String(entry));
      }
    }
  }
  return {
    ...storedResponse,
    headers: [...merged.entries()],
  };
}

export async function storeResponse(
  responseValue: unknown,
  set: Context["set"]
): Promise<StoreResponseResult> {
  if (responseValue instanceof Response) {
    const clone = responseValue.clone();
    const body = await readBoundedResponseBody(clone);
    if (body === undefined) {
      return unreplayable();
    }
    const headers = replayableHeaders(clone.headers);
    return storedResponseResult(headers, body, effectiveResponseStatus(responseValue, set));
  }

  return storeResponseSync(responseValue, set);
}

export function storeResponseSync(
  responseValue: unknown,
  set: Context["set"]
): StoreResponseResult {
  if (responseValue instanceof Response) {
    if (responseValue.body !== null) {
      return unreplayable();
    }
    return storedResponseResult(
      replayableHeaders(responseValue.headers),
      new Uint8Array(),
      effectiveResponseStatus(responseValue, set)
    );
  }
  const headers = responseHeaders(effectiveResponseHeaders(responseValue, set));
  const value = responseValue instanceof ElysiaStatus ? responseValue.response : responseValue;
  const responseStatus =
    responseValue instanceof ElysiaStatus ? responseValue.status : statusCode(set.status);
  let body: Uint8Array;
  if (value === undefined || value === null) {
    body = new Uint8Array();
  } else if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    const contentType = new Response(String(value)).headers.get("content-type");
    if (!headers.has("content-type") && contentType !== null) {
      headers.set("content-type", contentType);
    }
    body = new TextEncoder().encode(String(value));
  } else {
    headers.set("content-type", headers.get("content-type") ?? "application/json;charset=utf-8");
    body = new TextEncoder().encode(JSON.stringify(value));
  }
  return storedResponseResult(headers, body, responseStatus);
}

export function replayResponse(stored: StoredResponse): Response {
  const body =
    stored.status === 204 || stored.status === 205 || stored.status === 304
      ? null
      : stored.body.slice();
  return new Response(body, {
    headers: replayableHeaders(stored.headers),
    status: stored.status,
  });
}

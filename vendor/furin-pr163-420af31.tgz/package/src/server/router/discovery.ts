// biome-ignore-all lint/performance/noAwaitInLoops: route discovery walks filesystem entries sequentially for deterministic ordering
import { existsSync } from "node:fs";
import type { RuntimePage, RuntimeRoute } from "../../client/internal/runtime-types.ts";
import { scanRouteManifest } from "../../plugin/route-tree.ts";
import type { ErrorComponent } from "../../shared/error.ts";
import type { NotFoundComponent } from "../../shared/not-found.ts";
import { collectRouteChainFromRoute, validateRouteChain } from "../../shared/utils/index.ts";
import { isDevelopment } from "../instance.ts";
import { type CompileContext, type CompiledModule, getCompileContext } from "../internal.ts";
import { adaptDefinedLayout, adaptDefinedPage, isDefinedRouteTerminal } from "./defined-route.ts";
import { resolveMode } from "./patterns.ts";
import { routeModuleSourceVersion } from "./source-version.ts";
import type { ResolvedRoute, RootLayout, SegmentBoundary } from "./types.ts";

export function isModuleNotFoundError(err: unknown): boolean {
  if (!err || (typeof err !== "object" && typeof err !== "string")) {
    return false;
  }
  const msg =
    typeof err === "string"
      ? err.toLowerCase()
      : String((err as { message?: unknown }).message ?? "").toLowerCase();
  const code = typeof err === "string" ? undefined : (err as { code?: string }).code;
  return (
    code === "ENOENT" ||
    code === "ERR_MODULE_NOT_FOUND" ||
    code === "MODULE_NOT_FOUND" ||
    msg.includes("cannot find module") ||
    msg.includes("module not found") ||
    msg.includes("no such file or directory")
  );
}

export async function annotateScannedRequestKeys(routes: ResolvedRoute[]): Promise<void> {
  // Build and dev have source files; production routes receive serialized keys
  // from CompileContext and never load the TypeScript compiler.
  const extension = import.meta.url.endsWith(".ts") ? "ts" : "js";
  const moduleUrl = new URL(`../../build/request-keys.${extension}`, import.meta.url).href;
  const compiler = (await import(moduleUrl)) as typeof import("../../build/request-keys.ts");
  await compiler.annotateRequestLoaderKeys(routes);
}

/** @internal Exported for unit testing. */
export function collectRouteTags(
  routeChain: RuntimeRoute[],
  page: Pick<RuntimePage, "tags"> | undefined
): string[] | undefined {
  const tags = new Set<string>();
  for (const route of routeChain) {
    for (const tag of route.tags ?? []) {
      tags.add(tag);
    }
  }
  for (const tag of page?.tags ?? []) {
    tags.add(tag);
  }
  return tags.size > 0 ? [...tags] : undefined;
}

export function loadProdRoutes(ctx: CompileContext): {
  root: RootLayout;
  routes: ResolvedRoute[];
} {
  const rootExport = ctx.modules[ctx.rootPath]?.route;
  if (!isDefinedRouteTerminal(rootExport) || typeof rootExport.layout !== "function") {
    throw new Error("[furin] root.tsx: defineRootRoute().layout() not found in CompileContext.");
  }
  const rootRoute = adaptDefinedLayout(rootExport, undefined, ctx.rootPath);

  function resolveModuleComponent<T>(modPath: string | undefined): T | undefined {
    if (!modPath) {
      return;
    }
    return ctx.modules[modPath]?.default as T | undefined;
  }

  const root: RootLayout = {
    error: resolveModuleComponent(ctx.rootConventions?.errorPath),
    notFound: resolveModuleComponent(ctx.rootConventions?.notFoundPath),
    path: ctx.rootPath,
    route: rootRoute,
  };

  const routes: ResolvedRoute[] = [];
  for (const { pattern, path, mode } of ctx.routes) {
    const page = resolveCompiledRuntimePage(ctx.modules[path] ?? {}, path, root, ctx);
    if (!page) {
      throw new Error(`[furin] ${path}: invalid page module in CompileContext.`);
    }
    const routeChain = collectRouteChainFromRoute(page._route as RuntimeRoute);
    validateRouteChain(routeChain, root.route, path);
    const meta = ctx.routeMetadata?.[path];
    const boundaries = (meta?.segmentBoundaries ?? []).map((b) => ({
      ...b,
      error: resolveModuleComponent(b.errorPath),
      notFound: resolveModuleComponent(b.notFoundPath),
    })) as SegmentBoundary[];

    routes.push({
      mode,
      page,
      path,
      pattern,
      requestKeys: meta?.requestKeys,
      requestKeysByLoader: meta?.requestKeysByLoader,
      routeChain,
      segmentBoundaries: boundaries,
      tags: collectRouteTags(routeChain, page),
    });
  }

  return { root, routes };
}

function resolveCompiledRuntimePage(
  module: { route?: unknown },
  path: string,
  root: RootLayout,
  context: CompileContext
): RuntimePage | undefined {
  if (!isDefinedRouteTerminal(module.route) || typeof module.route.page !== "function") {
    return;
  }
  const pagesDir = root.path.slice(0, root.path.lastIndexOf("/"));
  const parent = resolveCompiledLayoutParent(path, pagesDir, root.route, context);
  return adaptDefinedPage(module.route, parent);
}

export function invalidNestedLayoutError(layoutPath: string): Error {
  return new Error(
    `[furin] ${layoutPath}: _route.tsx must export \`route = defineRoute(id).config({ mode }).layout(({ children }) => ...)\`, with the file's id. For example, in blog/_route.tsx:
  export const route = defineRoute("/blog/_route")
    .config({ mode: "ssr" })
    .layout(({ children }) => <section>{children}</section>);`
  );
}

function resolveCompiledLayoutParent(
  pagePath: string,
  pagesDir: string,
  rootRoute: RuntimeRoute,
  context: CompileContext
): RuntimeRoute {
  const pageDirectory = pagePath.slice(0, pagePath.lastIndexOf("/"));
  if (pageDirectory.length <= pagesDir.length) {
    return rootRoute;
  }
  const segments = pageDirectory.slice(pagesDir.length + 1).split("/");
  let directory = pagesDir;
  let parent = rootRoute;

  for (const segment of segments) {
    directory = `${directory}/${segment}`;
    for (const candidate of getSourceModuleCandidates(directory, "_route")) {
      const layoutModule = context.modules[candidate];
      if (!layoutModule) {
        continue;
      }
      const layout = layoutModule.route;
      if (!isDefinedRouteTerminal(layout) || typeof layout.layout !== "function") {
        throw invalidNestedLayoutError(candidate);
      }
      parent = adaptDefinedLayout(layout, parent, candidate);
      break;
    }
  }

  return parent;
}

/**
 * Normalises OS-native path separators to POSIX "/" so the slash-based path
 * arithmetic in the scan (relative slicing, `lastIndexOf("/")`,
 * `${pagesDir}/...`) works on Windows, where `node:path` join/resolve emit
 * backslashes. `existsSync` and dynamic `import()` both accept forward slashes
 * on Windows, so the normalised form is safe for filesystem and module access.
 */
function toPosixPath(path: string): string {
  return path.replaceAll("\\", "/");
}

function routeRelativePath(pagesDir: string, absolutePath: string): string {
  const dir = toPosixPath(pagesDir).replace(/\/+$/g, "");
  const path = toPosixPath(absolutePath);
  return path.startsWith(`${dir}/`) ? path.slice(dir.length + 1) : path;
}

export async function scanPages(pagesDir: string): Promise<{
  root: RootLayout;
  routes: ResolvedRoute[];
}> {
  // Normalise once at the entry point; scanRootLayout and scanPageFiles (which
  // also normalises every route-manifest path) then operate purely on
  // POSIX-separated paths.
  const dir = toPosixPath(pagesDir);
  const root = await scanRootLayout(dir);
  const routes = await scanPageFiles(dir, root);
  if (routes.some((route) => route.routeChain.some((entry) => entry.requestLoader))) {
    await annotateScannedRequestKeys(routes);
  }
  return { root, routes };
}

const ROOT_EXAMPLE = `  export const route = defineRootRoute()
    .config({ mode: "ssr" })
    .layout(({ children }) => (
      <html lang="en">
        <head><HeadContent /></head>
        <body>{children}<Scripts /></body>
      </html>
    ));`;

const CONVENTION_EXAMPLES = {
  error: `  export default function ErrorPage({ error, reset }: ErrorProps) {
    return <button onClick={reset}>{error.message}</button>;
  }`,
  "not-found": `  export default function NotFound() {
    return <h1>Page not found</h1>;
  }`,
} as const;

export async function scanRootLayout(pagesDir: string): Promise<RootLayout> {
  const rootPath = `${pagesDir}/root.tsx`;
  const ctx = getCompileContext();
  if (!(existsSync(rootPath) || ctx?.modules[rootPath])) {
    throw new Error(
      `[furin] root.tsx: not found in ${pagesDir}. Every pages directory needs a root layout:\n${ROOT_EXAMPLE}`
    );
  }

  // Dev loads root through the same versioned identity as the renderer and
  // the pages' rewritten imports, so its top level runs once per edit.
  const mod = (ctx?.modules[rootPath] ??
    (await import(
      isDevelopment()
        ? `${rootPath}?furin-server&t=${routeModuleSourceVersion(rootPath)}`
        : rootPath
    ))) as CompiledModule;
  const rootExport = mod.route;
  if (!isDefinedRouteTerminal(rootExport)) {
    throw new Error(
      `[furin] ${rootPath}: root.tsx must export \`route = defineRootRoute().config({ mode }).layout(...)\`:\n${ROOT_EXAMPLE}`
    );
  }

  if (!rootExport.layout) {
    throw new Error(
      `[furin] ${rootPath}: root.tsx: defineRootRoute() must end with .layout(({ children }) => ...):\n${ROOT_EXAMPLE}`
    );
  }
  const rootRoute = adaptDefinedLayout(rootExport, undefined, rootPath);

  const [notFoundEntry, errorEntry] = await Promise.all([
    loadConventionComponent<NotFoundComponent>(pagesDir, "not-found"),
    loadConventionComponent<ErrorComponent>(pagesDir, "error"),
  ]);
  return {
    error: errorEntry?.component,
    errorPath: errorEntry?.path,
    notFound: notFoundEntry?.component,
    notFoundPath: notFoundEntry?.path,
    path: rootPath,
    route: rootRoute,
  };
}

const CONVENTION_FILE_NAMES = ["not-found", "error"] as const;
const SOURCE_MODULE_EXTENSIONS = [".tsx", ".ts", ".jsx", ".js"] as const;

export function getSourceModuleCandidates(dir: string, name: string): string[] {
  return SOURCE_MODULE_EXTENSIONS.map((ext) => `${dir}/${name}${ext}`);
}

/**
 * Result of a convention-file lookup. The `path` is the absolute module path
 * — callers that only care about the component discard it, but the hydrate
 * emission pipeline needs it to generate static `import` statements.
 */
interface ConventionLookup<T> {
  component: T;
  path: string;
}

async function loadConventionComponent<T>(
  dir: string,
  name: (typeof CONVENTION_FILE_NAMES)[number]
): Promise<ConventionLookup<T> | undefined> {
  const ctx = getCompileContext();
  for (const filePath of getSourceModuleCandidates(dir, name)) {
    if (existsSync(filePath) || ctx?.modules[filePath]) {
      const moduleSpecifier =
        isDevelopment() && existsSync(filePath)
          ? `${filePath}?furin-server&t=${routeModuleSourceVersion(filePath)}`
          : filePath;
      const mod = (ctx?.modules[filePath] ?? (await import(moduleSpecifier))) as {
        default?: T;
      };
      if (mod.default) {
        return { component: mod.default, path: filePath };
      }
      const exportNames = Object.keys(mod).join(", ") || "none";
      throw new Error(
        `[furin] ${filePath}: ${name}.tsx must default-export a React component (found exports: ${exportNames}). For example:\n${CONVENTION_EXAMPLES[name]}`
      );
    }
  }
}

async function scanPageFiles(pagesDir: string, root: RootLayout): Promise<ResolvedRoute[]> {
  const routes: ResolvedRoute[] = [];
  const notFoundCache = new Map<string, ConventionLookup<NotFoundComponent> | undefined>();
  const errorCache = new Map<string, ConventionLookup<ErrorComponent> | undefined>();

  for (const { pattern, sourcePath } of scanRouteManifest(pagesDir)) {
    if (pattern === undefined) {
      continue;
    }
    const absolutePath = toPosixPath(sourcePath);
    const relativePath = routeRelativePath(pagesDir, absolutePath);

    const segmentBoundaries = await collectSegmentBoundaries(
      absolutePath,
      pagesDir,
      notFoundCache,
      errorCache
    );

    if (isDevelopment()) {
      const devRoute = await buildDevRoute(absolutePath, relativePath, pattern, root, pagesDir);
      devRoute.segmentBoundaries = alignSegmentBoundaryDepths(
        segmentBoundaries,
        devRoute.routeChain
      );
      routes.push(devRoute);
      continue;
    }

    const ctx = getCompileContext();
    const pageMod = (ctx?.modules[absolutePath] ?? (await import(absolutePath))) as {
      route?: unknown;
    };
    const page = await resolveRuntimePage(pageMod, absolutePath, pagesDir, root.route);
    if (!page) {
      throw new Error(`[furin] ${relativePath}: no valid defineRoute(id).page() export found`);
    }

    const routeChain = collectRouteChainFromRoute(page._route as RuntimeRoute);

    validateRouteChain(routeChain, root.route, relativePath);

    routes.push({
      mode: resolveMode(page, routeChain),
      page,
      path: absolutePath,
      pattern,
      routeChain,
      segmentBoundaries: alignSegmentBoundaryDepths(segmentBoundaries, routeChain),
      tags: collectRouteTags(routeChain, page),
    });
  }

  return routes;
}

async function resolveRuntimePage(
  module: { route?: unknown },
  absolutePath: string,
  pagesDir: string,
  rootRoute: RuntimeRoute
): Promise<RuntimePage | undefined> {
  if (!isDefinedRouteTerminal(module.route) || typeof module.route.page !== "function") {
    return;
  }
  const parent = await resolveDefinedLayoutParent(absolutePath, pagesDir, rootRoute);
  return adaptDefinedPage(module.route, parent);
}

async function resolveDefinedLayoutParent(
  pagePath: string,
  pagesDir: string,
  rootRoute: RuntimeRoute
): Promise<RuntimeRoute> {
  const pageDirectory = pagePath.slice(0, pagePath.lastIndexOf("/"));
  if (pageDirectory.length <= pagesDir.length) {
    return rootRoute;
  }
  const relativeDirectory = pageDirectory.slice(pagesDir.length + 1);
  const segments = relativeDirectory.split("/");
  let directory = pagesDir;
  let parent = rootRoute;

  for (const segment of segments) {
    directory = `${directory}/${segment}`;
    for (const candidate of getSourceModuleCandidates(directory, "_route")) {
      if (!existsSync(candidate)) {
        continue;
      }
      const layoutModule = (await import(
        isDevelopment()
          ? `${candidate}?furin-server&t=${routeModuleSourceVersion(candidate)}`
          : candidate
      )) as { route?: unknown };
      const layout = layoutModule.route;
      if (!isDefinedRouteTerminal(layout) || typeof layout.layout !== "function") {
        throw invalidNestedLayoutError(candidate);
      }
      parent = adaptDefinedLayout(layout, parent, candidate);
      break;
    }
  }

  return parent;
}

function alignSegmentBoundaryDepths(
  boundaries: SegmentBoundary[],
  routeChain: RuntimeRoute[]
): SegmentBoundary[] {
  return boundaries.map((boundary) => {
    let depth = 0;
    for (const [index, entry] of routeChain.entries()) {
      if (!entry.sourcePath) {
        continue;
      }
      const directory = entry.sourcePath.slice(0, entry.sourcePath.lastIndexOf("/"));
      if (boundary.path === directory || boundary.path.startsWith(`${directory}/`)) {
        depth = index;
      }
    }
    return { ...boundary, depth };
  });
}

/**
 * Walks every directory from `pagesDir` down to the directory containing
 * `pageAbsolutePath` and records the OWN (not inherited) error.tsx /
 * not-found.tsx declared there. Directories without any convention file are
 * omitted so consumers can treat each entry as "a place where the user
 * authored a boundary on purpose".
 *
 * Uses the shared per-directory caches so sibling pages don't re-import the
 * same convention modules.
 */
async function collectSegmentBoundaries(
  pageAbsolutePath: string,
  pagesDir: string,
  notFoundCache: Map<string, ConventionLookup<NotFoundComponent> | undefined>,
  errorCache: Map<string, ConventionLookup<ErrorComponent> | undefined>
): Promise<SegmentBoundary[]> {
  const pageDir = pageAbsolutePath.slice(0, pageAbsolutePath.lastIndexOf("/"));

  // Accumulate directories from shallow → deep starting at pagesDir.
  const dirs: string[] = [pagesDir];
  if (pageDir.length > pagesDir.length) {
    const relativeTail = pageDir.slice(pagesDir.length + 1); // skip leading "/"
    const parts = relativeTail.split("/");
    let acc = pagesDir;
    for (const part of parts) {
      acc = `${acc}/${part}`;
      dirs.push(acc);
    }
  }

  const boundaries: SegmentBoundary[] = [];
  for (let depth = 0; depth < dirs.length; depth += 1) {
    const dir = dirs[depth] as string;

    const [errorEntry, notFoundEntry] = await Promise.all([
      errorCache.has(dir)
        ? Promise.resolve(errorCache.get(dir))
        : loadConventionComponent<ErrorComponent>(dir, "error").then((r) => {
            errorCache.set(dir, r);
            return r;
          }),
      notFoundCache.has(dir)
        ? Promise.resolve(notFoundCache.get(dir))
        : loadConventionComponent<NotFoundComponent>(dir, "not-found").then((r) => {
            notFoundCache.set(dir, r);
            return r;
          }),
    ]);
    if (errorEntry || notFoundEntry) {
      boundaries.push({
        depth,
        error: errorEntry?.component,
        errorPath: errorEntry?.path,
        notFound: notFoundEntry?.component,
        notFoundPath: notFoundEntry?.path,
        path: dir,
      });
    }
  }

  return boundaries;
}

async function buildDevRoute(
  absolutePath: string,
  relativePath: string,
  pattern: string,
  root: RootLayout,
  pagesDir: string
): Promise<ResolvedRoute> {
  // Import via the virtual namespace (registerDevPagePlugin must be called first)
  // so page files stay out of --hot's module graph. We still extract the route
  // chain at startup for type generation, guards, and mode resolution — matching
  // prod behavior exactly.
  let page: RuntimePage | undefined;
  let routeChain: RuntimeRoute[] = [];

  try {
    const pageMod = (await import(
      `${absolutePath}?furin-server&t=${routeModuleSourceVersion(absolutePath)}`
    )) as {
      route?: unknown;
    };
    const resolvedPage = await resolveRuntimePage(pageMod, absolutePath, pagesDir, root.route);
    if (resolvedPage) {
      page = resolvedPage;
      routeChain = collectRouteChainFromRoute(page._route as RuntimeRoute);
      validateRouteChain(routeChain, root.route, relativePath);
    }
  } catch {
    // The dev renderer retries the named terminal on the first request.
  }

  // Dev stub: never rendered; the dev renderer re-imports from disk.
  const devStubPage: RuntimePage = {
    __type: "FURIN_PAGE",
    _route: { __type: "FURIN_ROUTE" },
    component: () => null,
  };

  return {
    mode: page ? resolveMode(page, routeChain) : "ssr",
    // Still lazily re-imported on each request for fresh code.
    page: page ?? devStubPage,
    path: absolutePath,
    pattern,
    routeChain,
    // scanPageFiles() overwrites this with the real chain before the route
    // is pushed — present here to satisfy the ResolvedRoute required shape.
    segmentBoundaries: [],
    tags: collectRouteTags(routeChain, page),
  };
}

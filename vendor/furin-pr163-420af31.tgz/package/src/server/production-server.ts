import type { AnyElysia } from "elysia";
import { closeBrowserEventConnections } from "./browser-events/shutdown.ts";
import { waitForPendingISRRevalidations } from "./cache/isr.ts";
import { setRequestEvlogWaitUntil, setRuntimeEvlogWaitUntil } from "./evlog.ts";
import { closeSyncCursorStates, waitForSyncCursorUnsubscriptions } from "./sync/stream.ts";

const DEFAULT_PRE_STOP_DELAY_MS = 5000;
const DEFAULT_SHUTDOWN_TIMEOUT_MS = 30_000;
const activeShutdowns = new Set<() => Promise<void>>();
const syncDrainsReached = new Set<() => Promise<void>>();

const signalShutdown = (): void => {
  Promise.allSettled([...activeShutdowns].map((shutdown) => shutdown())).then((results) => {
    let code = process.exitCode ?? 0;
    for (const result of results) {
      if (result.status === "rejected") {
        console.error("[furin] Graceful shutdown failed", result.reason);
        code = 1;
      }
    }
    process.exit(code);
  });
};

export interface ProductionServerOptions {
  app: AnyElysia;
  idleTimeout?: number;
  onShutdown?: () => Promise<void> | void;
  port: number;
  preStopDelayMs?: number;
  shutdownTimeoutMs?: number;
}

export function startProductionServer(options: ProductionServerOptions): {
  server: Bun.Server<unknown>;
  shutdown: () => Promise<void>;
} {
  const { app } = options;
  const pendingEmissions = new Set<Promise<unknown>>();
  let draining = false;
  let rejecting = false;

  const trackEmission = (emission: Promise<unknown>): void => {
    pendingEmissions.add(emission);
    emission.finally(() => pendingEmissions.delete(emission)).catch(() => undefined);
  };
  // Request logs drain on the server that received them; the process-wide
  // registration covers emissions without a request (ISR background renders).
  const unregisterWaitUntil = setRuntimeEvlogWaitUntil(trackEmission);

  app
    .wrap((fetch) => (request, ...rest) => {
      const path = new URL(request.url).pathname;
      if (rejecting && path !== "/_furin/health/live" && path !== "/_furin/health/ready") {
        return Promise.resolve(new Response("Service Unavailable", { status: 503 }));
      }
      setRequestEvlogWaitUntil(request, trackEmission);
      return fetch(request, ...rest);
    })
    .get("/_furin/health/live", () =>
      Response.json({ status: "alive" }, { headers: { "cache-control": "no-store" } })
    )
    .get("/_furin/health/ready", () =>
      Response.json(
        { status: draining ? "draining" : "ready" },
        { headers: { "cache-control": "no-store" }, status: draining ? 503 : 200 }
      )
    );

  app.listen(
    options.idleTimeout === undefined
      ? options.port
      : { idleTimeout: options.idleTimeout, port: options.port }
  );
  const { server } = app;
  if (!server) {
    throw new Error("[furin] Bun server did not start");
  }

  let shutdownPromise: Promise<void> | undefined;
  const drainSync = (): Promise<void> => {
    syncDrainsReached.add(shutdown);
    return syncDrainsReached.size === activeShutdowns.size
      ? closeSyncCursorStates()
      : waitForSyncCursorUnsubscriptions();
  };
  const shutdown = (): Promise<void> => {
    if (shutdownPromise) {
      return shutdownPromise;
    }
    draining = true;
    const timeoutMs = options.shutdownTimeoutMs ?? DEFAULT_SHUTDOWN_TIMEOUT_MS;
    const delayMs = options.preStopDelayMs ?? DEFAULT_PRE_STOP_DELAY_MS;
    shutdownPromise = (async () => {
      let timeout: ReturnType<typeof setTimeout> | undefined;
      let forced = false;
      try {
        await Bun.sleep(delayMs);
        rejecting = true;
        const deadline = new Promise<void>((resolve, reject) => {
          timeout = setTimeout(() => {
            forced = true;
            console.error("[furin] Shutdown deadline exceeded; forcing server stop");
            const stopped = server.stop(true);
            Promise.resolve(app.stop(true)).catch((error: unknown) => {
              console.error("[furin] Forced Elysia app cleanup failed", error);
            });
            drainSync().catch((error: unknown) => {
              console.error("[furin] Forced Sync cursor cleanup failed", error);
            });
            stopped.then(resolve, (error: unknown) => {
              console.error("[furin] Forced server stop failed", error);
              reject(error);
            });
          }, timeoutMs);
        });
        const drain = async (): Promise<void> => {
          const steps = [
            () => closeBrowserEventConnections(server),
            () => {
              server.closeIdleConnections();
              return server.stop();
            },
            waitForPendingISRRevalidations,
            () => Promise.allSettled([...pendingEmissions]),
            drainSync,
            () => app.stop(),
            () => options.onShutdown?.(),
          ];
          for (const step of steps) {
            if (forced) {
              return;
            }
            // biome-ignore lint/performance/noAwaitInLoops: each shutdown stage depends on the preceding drain.
            await step();
          }
        };
        await Promise.race([drain(), deadline]);
      } finally {
        if (timeout) {
          clearTimeout(timeout);
        }
        activeShutdowns.delete(shutdown);
        syncDrainsReached.delete(shutdown);
        if (activeShutdowns.size === 0) {
          process.off("SIGTERM", signalShutdown);
          process.off("SIGINT", signalShutdown);
        }
        unregisterWaitUntil();
      }
    })();
    return shutdownPromise;
  };

  if (activeShutdowns.size === 0) {
    process.on("SIGTERM", signalShutdown);
    process.on("SIGINT", signalShutdown);
  }
  activeShutdowns.add(shutdown);
  return { server, shutdown };
}

export const ACQUIRE_PAGE_CACHE_LEASE_SCRIPT = `
local raw = redis.call('GET', KEYS[1])
local now_parts = redis.call('TIME')
local now = tonumber(now_parts[1]) * 1000 + math.floor(tonumber(now_parts[2]) / 1000)
if raw then
  local active = cjson.decode(raw)
  if active.expiresAt > now then return nil end
  if active.indexMember then redis.call('ZREM', KEYS[4], active.indexMember) end
  for _, key in ipairs(active.tagLeaseKeys or {}) do
    redis.call('ZREM', key, active.indexMember)
  end
end
local fence = redis.call('INCR', KEYS[2])
redis.call('PEXPIRE', KEYS[2], ARGV[4])
local fields = cjson.decode(ARGV[3])
local values = {}
for index, field in ipairs(fields) do
  values[index] = tonumber(redis.call('HGET', KEYS[3], field) or '0')
end
redis.call('PEXPIRE', KEYS[3], ARGV[4])
local tag_lease_keys = {}
for index = 5, #KEYS do table.insert(tag_lease_keys, KEYS[index]) end
local lease = {
  tagLeaseKeys = tag_lease_keys,
  expiresAt = now + tonumber(ARGV[2]),
  fence = fence,
  fields = fields,
  id = ARGV[1],
  indexMember = cjson.encode({id = ARGV[1], path = ARGV[5], tags = cjson.decode(ARGV[6])}),
  values = values
}
redis.call('SET', KEYS[1], cjson.encode(lease), 'PX', ARGV[2])
redis.call('ZREMRANGEBYSCORE', KEYS[4], '-inf', now)
redis.call('ZADD', KEYS[4], lease.expiresAt, lease.indexMember)
redis.call('PEXPIRE', KEYS[4], ARGV[4])
for _, key in ipairs(tag_lease_keys) do
  redis.call('ZREMRANGEBYSCORE', key, '-inf', now)
  redis.call('ZADD', key, lease.expiresAt, lease.indexMember)
  redis.call('PEXPIRE', key, ARGV[4])
end
return cjson.encode(lease)
`;

export const COMMIT_PAGE_CACHE_ENTRY_SCRIPT = `
local raw = redis.call('GET', KEYS[1])
if not raw then return 'superseded' end
local lease = cjson.decode(raw)
local now_parts = redis.call('TIME')
local now = tonumber(now_parts[1]) * 1000 + math.floor(tonumber(now_parts[2]) / 1000)
if lease.id ~= ARGV[1] or lease.fence ~= tonumber(ARGV[2]) or lease.expiresAt <= now then
  return 'superseded'
end
for index, field in ipairs(lease.fields) do
  local current = tonumber(redis.call('HGET', KEYS[3], field) or '0')
  if current ~= lease.values[index] then
    redis.call('DEL', KEYS[1])
    if lease.indexMember then redis.call('ZREM', KEYS[5], lease.indexMember) end
    for _, key in ipairs(lease.tagLeaseKeys or {}) do redis.call('ZREM', key, lease.indexMember) end
    return 'superseded'
  end
end
local previous_raw = redis.call('GET', KEYS[2])
if previous_raw then
  local previous = cjson.decode(previous_raw)
  if previous.indexMember then
    redis.call('ZREM', previous.pathsKey, previous.indexMember)
    for _, tag_key in ipairs(previous.tagKeys) do
      redis.call('ZREM', tag_key, previous.indexMember)
    end
  end
end
local expires_at = now + tonumber(ARGV[5])
redis.call('SET', KEYS[2], ARGV[3], 'PX', ARGV[5])
redis.call('ZREMRANGEBYSCORE', KEYS[4], '-inf', now)
redis.call('ZADD', KEYS[4], expires_at, ARGV[4])
redis.call('PEXPIRE', KEYS[4], ARGV[6])
for index = 6, #KEYS do
  redis.call('ZREMRANGEBYSCORE', KEYS[index], '-inf', now)
  redis.call('ZADD', KEYS[index], expires_at, ARGV[4])
  redis.call('PEXPIRE', KEYS[index], ARGV[6])
end
redis.call('PEXPIRE', KEYS[3], ARGV[6])
redis.call('DEL', KEYS[1])
if lease.indexMember then redis.call('ZREM', KEYS[5], lease.indexMember) end
for _, key in ipairs(lease.tagLeaseKeys or {}) do redis.call('ZREM', key, lease.indexMember) end
return 'stored'
`;

export const READ_PAGE_CACHE_ENTRY_SCRIPT = `
local raw = redis.call('GET', KEYS[1])
if not raw then return nil end
local value = cjson.decode(raw)
for index, field in ipairs(value.fields) do
  local current = tonumber(redis.call('HGET', KEYS[2], field) or '0')
  if current ~= value.values[index] then
    redis.call('DEL', KEYS[1])
    if value.indexMember then
      redis.call('ZREM', value.pathsKey, value.indexMember)
      for _, tag_key in ipairs(value.tagKeys) do
        redis.call('ZREM', tag_key, value.indexMember)
      end
    end
    return nil
  end
end
return raw
`;

export const RELEASE_PAGE_CACHE_LEASE_SCRIPT = `
local raw = redis.call('GET', KEYS[1])
if not raw then return 0 end
local lease = cjson.decode(raw)
if lease.id == ARGV[1] and lease.fence == tonumber(ARGV[2]) then
  if lease.indexMember then redis.call('ZREM', KEYS[2], lease.indexMember) end
  for _, key in ipairs(lease.tagLeaseKeys or {}) do redis.call('ZREM', key, lease.indexMember) end
  return redis.call('DEL', KEYS[1])
end
return 0
`;

export const INVALIDATE_PAGE_CACHE_PATH_SCRIPT = `
redis.call('HINCRBY', KEYS[1], ARGV[1], 1)
redis.call('PEXPIRE', KEYS[1], ARGV[4])
local now_parts = redis.call('TIME')
local now = tonumber(now_parts[1]) * 1000 + math.floor(tonumber(now_parts[2]) / 1000)
local function matching_members(key)
  redis.call('ZREMRANGEBYSCORE', key, '-inf', now)
  if ARGV[3] == 'layout' and ARGV[2] == '/' then
    return redis.call('ZRANGE', key, 0, -1)
  end
  local needle = key == KEYS[2] and ARGV[5] or ARGV[6]
  local members = {}
  local offset = 0
  repeat
    local batch = redis.call('ZRANGE', key, offset, offset + 999)
    for _, member in ipairs(batch) do
      if string.find(member, needle, 1, true) then
        table.insert(members, member)
      end
    end
    offset = offset + #batch
  until #batch < 1000
  return members
end
local members = matching_members(KEYS[2])
local seen = {}
local affected = {}
local function matches_path(path)
  if path == ARGV[2] then return true end
  return ARGV[3] == 'layout' and (ARGV[2] == '/' or string.sub(path, 1, string.len(ARGV[2]) + 1) == ARGV[2] .. '/')
end
for _, member in ipairs(members) do
  local index = cjson.decode(member)
  if matches_path(index.path) then
    redis.call('DEL', index.entryKey)
    redis.call('ZREM', index.pathsKey, member)
    for _, tag_key in ipairs(index.tagKeys) do
      redis.call('ZREM', tag_key, member)
    end
    if not seen[index.path] then
      seen[index.path] = true
      table.insert(affected, index.path)
    end
  end
end
for _, member in ipairs(matching_members(KEYS[3])) do
  local lease = cjson.decode(member)
  if matches_path(lease.path) and not seen[lease.path] then
    seen[lease.path] = true
    table.insert(affected, lease.path)
  end
end
return affected
`;

export const INVALIDATE_PAGE_CACHE_TAGS_SCRIPT = `
local tags = cjson.decode(ARGV[1])
for _, tag in ipairs(tags) do
  redis.call('HINCRBY', KEYS[1], 'tag:' .. tag, 1)
end
redis.call('PEXPIRE', KEYS[1], ARGV[2])
local now_parts = redis.call('TIME')
local now = tonumber(now_parts[1]) * 1000 + math.floor(tonumber(now_parts[2]) / 1000)
local seen_members = {}
local seen_paths = {}
local affected = {}
for key_index = 4, 3 + #tags do
  redis.call('ZREMRANGEBYSCORE', KEYS[key_index], '-inf', now)
  local members = redis.call('ZRANGE', KEYS[key_index], 0, -1)
  for _, member in ipairs(members) do
    if not seen_members[member] then
      seen_members[member] = true
      local index = cjson.decode(member)
      redis.call('DEL', index.entryKey)
      redis.call('ZREM', index.pathsKey, member)
      for _, tag_key in ipairs(index.tagKeys) do
        redis.call('ZREM', tag_key, member)
      end
      if not seen_paths[index.path] then
        seen_paths[index.path] = true
        table.insert(affected, index.path)
      end
    end
  end
end
for key_index = 4 + #tags, #KEYS do
  redis.call('ZREMRANGEBYSCORE', KEYS[key_index], '-inf', now)
  for _, member in ipairs(redis.call('ZRANGE', KEYS[key_index], 0, -1)) do
    local lease = cjson.decode(member)
    if not seen_paths[lease.path] then
      seen_paths[lease.path] = true
      table.insert(affected, lease.path)
    end
  end
end
return affected
`;

import type { Context } from "elysia";
import { isInvalidatedPath } from "../../shared/invalidation-header.ts";
import {
  buildSearchParams,
  collectSearchDefaults,
  type SearchParamsInput,
} from "../../shared/search-params.ts";
import { mergeRouteSchemas } from "../router/schema-merge.ts";
import type { ResolvedRoute } from "../router/types.ts";

export type RevalidateType = "page" | "layout";

interface CacheInvalidationResult {
  deleted: boolean;
  purgedPaths: string[];
}

export interface CacheGeneration {
  valid: boolean;
}

export interface Cache<Entry> {
  captureGeneration: (key: string) => CacheGeneration;
  clear: () => void;
  delete: (key: string) => boolean;
  entries: () => IterableIterator<[string, Entry]>;
  get: (key: string) => Entry | undefined;
  has: (key: string) => boolean;
  invalidatePath: (path: string, type: RevalidateType) => CacheInvalidationResult;
  keys: () => IterableIterator<string>;
  readonly name: string;
  releaseGeneration: (key: string, generation: CacheGeneration) => void;
  set: (key: string, entry: Entry) => void;
  get size(): number;
  readonly store: Map<string, Entry>;
}

export interface RouteCacheOptions<Entry> {
  maxSize?: number;
  name: string;
  onDelete?: (key: string, entry: Entry) => void;
  onSet?: (key: string, entry: Entry, previous: Entry | undefined) => void;
  pathFromKey?: (key: string) => string | null;
}

function defaultPathFromKey(key: string): string {
  return key;
}

export function pathWithoutSearch(path: string): string {
  const searchStart = path.indexOf("?");
  if (searchStart === -1) {
    return path;
  }
  return path.slice(0, searchStart);
}

/**
 * The cache key for a cached render of `path` and the context that render must
 * use. The key holds the query as the route's schema decoded it (none when the
 * route declares no query schema), re-serialised the way client links build
 * URLs: undeclared params dropped, schema defaults omitted, params sorted. So
 * `?page=01`, `?page=1` and `?junk=x&page=1` share one entry. The context's
 * request URL carries exactly that search, so every URL sharing the key would
 * have rendered the same output. Invalid queries never get here: route
 * validation rejects them first.
 */
export function canonicalCacheRequest(
  route: ResolvedRoute,
  path: string,
  ctx: Context
): { cacheKey: string; ctx: Context } {
  const querySchema = mergeRouteSchemas(route.routeChain, "query");
  const params =
    querySchema === undefined
      ? new URLSearchParams()
      : buildSearchParams(
          (ctx.query ?? {}) as SearchParamsInput,
          collectSearchDefaults(querySchema)
        );
  params.sort();
  const search = params.toString();
  const cacheKey = search === "" ? pathWithoutSearch(path) : `${pathWithoutSearch(path)}?${search}`;
  const url = new URL(ctx.request.url);
  url.search = search;
  return {
    cacheKey,
    ctx: Object.create(ctx, {
      query: { enumerable: true, value: querySchema === undefined ? {} : ctx.query },
      request: { enumerable: true, value: new Request(url, { headers: ctx.request.headers }) },
    }) as Context,
  };
}

export function createRouteCache<Entry>(options: RouteCacheOptions<Entry>): Cache<Entry> {
  const store = new Map<string, Entry>();
  const generations = new Map<string, Set<CacheGeneration>>();
  const pathFromKey = options.pathFromKey ?? defaultPathFromKey;

  const invalidateGenerations = (key: string): void => {
    for (const generation of generations.get(key) ?? []) {
      generation.valid = false;
    }
    generations.delete(key);
  };

  const evictOldest = (): void => {
    if (options.maxSize === undefined || store.size <= options.maxSize) {
      return;
    }
    const oldest = store.keys().next().value;
    if (oldest !== undefined) {
      deleteEntry(oldest);
    }
  };

  const deleteEntry = (key: string): boolean => {
    invalidateGenerations(key);
    const entry = store.get(key);
    if (entry === undefined) {
      return false;
    }
    store.delete(key);
    options.onDelete?.(key, entry);
    return true;
  };

  return {
    captureGeneration(key) {
      const generation = { valid: true };
      let pending = generations.get(key);
      if (pending === undefined) {
        pending = new Set();
        generations.set(key, pending);
      }
      pending.add(generation);
      return generation;
    },
    clear() {
      for (const key of generations.keys()) {
        invalidateGenerations(key);
      }
      for (const key of [...store.keys()]) {
        deleteEntry(key);
      }
      store.clear();
    },
    delete(key) {
      return deleteEntry(key);
    },
    entries() {
      return store.entries();
    },
    get(key) {
      const entry = store.get(key);
      if (entry !== undefined && options.maxSize !== undefined) {
        store.delete(key);
        store.set(key, entry);
      }
      return entry;
    },
    has(key) {
      return store.has(key);
    },
    invalidatePath(path, type) {
      let deleted = false;
      const purgedPaths: string[] = [];

      for (const key of new Set([...store.keys(), ...generations.keys()])) {
        const urlPath = pathFromKey(key);
        if (urlPath === null || !isInvalidatedPath(urlPath, path, type)) {
          continue;
        }
        if (deleteEntry(key)) {
          deleted = true;
          purgedPaths.push(urlPath);
        }
      }

      return { deleted, purgedPaths: [...new Set(purgedPaths)] };
    },
    keys() {
      return store.keys();
    },
    name: options.name,
    releaseGeneration(key, generation) {
      const pending = generations.get(key);
      pending?.delete(generation);
      if (pending?.size === 0) {
        generations.delete(key);
      }
    },
    set(key, entry) {
      const previous = store.get(key);
      if (previous !== undefined) {
        store.delete(key);
      }
      store.set(key, entry);
      options.onSet?.(key, entry, previous);
      evictOldest();
    },
    get size() {
      return store.size;
    },
    store,
  };
}

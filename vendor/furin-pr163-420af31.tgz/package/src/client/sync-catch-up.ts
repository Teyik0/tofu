// biome-ignore-all lint/performance/noAwaitInLoops: sync catch-up pages must be fetched sequentially by cursor
import type { SyncInvalidation } from "../server/sync/adapter.ts";
import { encodeInvalidationEntry } from "../shared/invalidation-header.ts";
import { type QueryIdentity, queryFromTag } from "../shared/sync-query.ts";

interface SyncChangePayload {
  cursor: string;
  invalidations: readonly (string | SyncInvalidation)[];
  queries?: readonly QueryIdentity[];
}

export interface SyncChangePagePayload {
  changes: readonly SyncChangePayload[];
  cursor: string;
  hasMore: boolean;
  reset: boolean;
}

interface SyncCatchUpOptions {
  fetchPage: (after: string | undefined) => Promise<SyncChangePagePayload>;
  onInvalidations: (invalidations: readonly string[]) => void;
  onQueries?: (identities: readonly QueryIdentity[]) => void;
  onReset?: () => void;
}

const LAYOUT_SUFFIX_RE = /:layout$/;
/** Minimum spacing between reset-driven full refreshes; the trailing one always runs. */
const RESET_REFRESH_INTERVAL_MS = 1000;

function changeInvalidations(change: SyncChangePayload): {
  paths: string[];
  queries: QueryIdentity[];
} {
  const paths: string[] = [];
  const queries = [...(change.queries ?? [])];
  for (const entry of change.invalidations) {
    if (typeof entry === "string") {
      const trimmed = entry.trim();
      const type = trimmed.endsWith(":layout") ? "layout" : "page";
      const path = trimmed.replace(LAYOUT_SUFFIX_RE, "");
      paths.push(encodeInvalidationEntry(path, type));
    } else if (entry.kind === "path") {
      paths.push(encodeInvalidationEntry(entry.path, entry.type));
    } else {
      for (const tag of entry.tags) {
        const identity = queryFromTag(tag);
        if (identity) {
          queries.push(identity);
        } else {
          paths.push("/:layout");
        }
      }
    }
  }
  return { paths, queries };
}

export interface SyncCatchUp {
  catchUp: () => Promise<void>;
  close: () => void;
  cursor: () => string | undefined;
  seed: (cursor: string) => void;
}

interface InvalidationRefreshOptions {
  onError: (error: unknown) => void;
  refresh: () => Promise<void>;
}

export interface InvalidationRefresh {
  run: () => Promise<void>;
}

export function createInvalidationRefresh(
  options: InvalidationRefreshOptions
): InvalidationRefresh {
  let running: Promise<void> | undefined;
  let requested = false;

  const refreshUntilCurrent = async (): Promise<void> => {
    do {
      requested = false;
      try {
        await options.refresh();
      } catch (error) {
        if (!isAbortError(error)) {
          throw error;
        }
      }
    } while (requested);
  };

  return {
    run() {
      requested = true;
      if (!running) {
        running = refreshUntilCurrent()
          .catch((error: unknown) => {
            if (!isAbortError(error)) {
              options.onError(error);
            }
          })
          .finally(() => {
            running = undefined;
          });
      }
      return running;
    },
  };
}

export function createSyncCatchUp(options: SyncCatchUpOptions): SyncCatchUp {
  let currentCursor: string | undefined;
  let running: Promise<void> | undefined;
  let requested = false;
  let lastReset = Number.NEGATIVE_INFINITY;
  let pendingReset: ReturnType<typeof setTimeout> | undefined;
  let closed = false;

  const refreshAfterReset = () => {
    pendingReset = undefined;
    lastReset = Date.now();
    options.onReset?.();
    options.onInvalidations(["/:layout"]);
  };

  // Another principal's write loop must not re-run every loader on every commit.
  const scheduleResetRefresh = () => {
    if (pendingReset) {
      return;
    }
    const wait = lastReset + RESET_REFRESH_INTERVAL_MS - Date.now();
    if (wait <= 0) {
      refreshAfterReset();
    } else {
      pendingReset = setTimeout(refreshAfterReset, wait);
    }
  };

  const readUntilCurrent = async (): Promise<void> => {
    do {
      requested = false;
      let page: SyncChangePagePayload;
      do {
        page = await options.fetchPage(currentCursor ?? "0");
        if (closed) {
          return;
        }
        if (page.reset) {
          currentCursor = page.cursor;
          scheduleResetRefresh();
          break;
        }
        for (const change of page.changes) {
          applyChange(change);
        }
        currentCursor = page.cursor;
      } while (page.hasMore);
    } while (requested && !closed);
  };

  const applyChange = (change: SyncChangePayload) => {
    const { paths, queries } = changeInvalidations(change);
    options.onInvalidations(paths);
    if (queries.length > 0) {
      options.onQueries?.(queries);
    }
  };

  return {
    catchUp() {
      if (closed) {
        return Promise.resolve();
      }
      requested = true;
      if (!running) {
        running = readUntilCurrent().finally(() => {
          running = undefined;
        });
      }
      return running;
    },
    cursor: () => currentCursor,
    close() {
      closed = true;
      clearTimeout(pendingReset);
    },
    seed(cursor) {
      currentCursor ??= cursor;
    },
  };
}

import { isAbortError } from "./router/abort.ts";
